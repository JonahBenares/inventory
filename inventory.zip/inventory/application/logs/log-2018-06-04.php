<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-04 08:49:06 --> Severity: Warning --> mkdir(): Permission denied C:\Users\User\Dropbox\xampp\htdocs\inventory\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2018-06-04 08:49:06 --> Severity: error --> Exception: Session: Configured save path 'C:\Users\Jonah\Dropbox\xampp\tmp' is not a directory, doesn't exist or cannot be created. C:\Users\User\Dropbox\xampp\htdocs\inventory\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2018-06-04 08:49:07 --> Severity: Warning --> mkdir(): Permission denied C:\Users\User\Dropbox\xampp\htdocs\inventory\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2018-06-04 08:49:07 --> Severity: error --> Exception: Session: Configured save path 'C:\Users\Jonah\Dropbox\xampp\tmp' is not a directory, doesn't exist or cannot be created. C:\Users\User\Dropbox\xampp\htdocs\inventory\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2018-06-04 08:49:07 --> Severity: Warning --> mkdir(): Permission denied C:\Users\User\Dropbox\xampp\htdocs\inventory\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2018-06-04 08:49:07 --> Severity: error --> Exception: Session: Configured save path 'C:\Users\Jonah\Dropbox\xampp\tmp' is not a directory, doesn't exist or cannot be created. C:\Users\User\Dropbox\xampp\htdocs\inventory\system\libraries\Session\drivers\Session_files_driver.php 138
