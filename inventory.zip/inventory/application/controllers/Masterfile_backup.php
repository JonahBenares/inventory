<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Masterfile extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
        $this->load->model('super_model');
        date_default_timezone_set("Asia/Manila");
        $this->dropdown['department'] = $this->super_model->select_all_order_by('department', 'department_name', 'ASC');
        $this->dropdown['purpose'] = $this->super_model->select_all_order_by('purpose', 'purpose_desc', 'ASC');
        $this->dropdown['enduse'] = $this->super_model->select_all_order_by('enduse', 'enduse_name', 'ASC');
         $this->dropdown['prno'] = $this->super_model->select_join_where("receive_details","receive_head", "saved='1' AND create_date BETWEEN CURDATE() - INTERVAL 60 DAY AND CURDATE()","receive_id");
        function arrayToObject($array){
            if(!is_array($array)) { return $array; }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) { $object->$name = arrayToObject($value); }
                }
                return $object;
            } 
            else {
                return false;
            }
        }
    }

    public function index(){ 
        $this->load->view('template/header_login');
        $this->load->view('masterfile/login');
        $this->load->view('template/footer');
    }

    public function home(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/index');
        $this->load->view('template/footer');
    }

    public function login_process(){
        $username=$this->input->post('username');
        $password=$this->input->post('password');
        $count=$this->super_model->login_user($username,$password);
        if($count>0){   
            $fetch=$this->super_model->select_custom_where("users", "username = '$username' AND password = '$password'");
            foreach($fetch AS $d){
                $userid = $d->user_id;
                $usertype = $d->usertype_id;
                $username = $d->username;
            }
            $newdata = array(
               'user_id'=> $userid,
               'usertype'=> $usertype,
               'username'=> $username,
               'logged_in'=> TRUE
            );
            $this->session->set_userdata($newdata);
            redirect(base_url().'index.php/masterfile/home/');
        }
        else{
            $this->session->set_flashdata('error_msg', 'Username And Password Do not Exist!');
            $this->load->view('template/header_login');
            $this->load->view('masterfile/login');
            $this->load->view('template/footer');       
        }
    }

    public function user_logout(){
        $this->session->sess_destroy();
        $this->load->view('template/header');
        $this->load->view('masterfile/login');
        $this->load->view('template/footer');
        echo "<script>alert('You have successfully logged out.'); 
        window.location ='".base_url()."index.php/masterfile/index'; </script>";
    }

    public function supplier_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['list'] = $this->super_model->select_all('supplier');
        $this->load->view('masterfile/supplier_list',$data);
        $this->load->view('template/footer');
    }

    public function category_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['category'] = $this->super_model->select_all('item_categories'); 
        $data['subcat'] = $this->super_model->select_all('item_subcat'); 
        $this->load->view('masterfile/category_list',$data);
        $this->load->view('template/footer');
    }

    public function department_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['department'] = $this->super_model->select_all('department');
        $this->load->view('masterfile/department_list',$data);
        $this->load->view('template/footer');
    }

    public function location_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['location'] = $this->super_model->select_all('location');
        $this->load->view('masterfile/location_list',$data);
        $this->load->view('template/footer');
    }

    public function endUse_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['enduse'] = $this->super_model->select_all('enduse');
        $this->load->view('masterfile/endUse_list', $data);
        $this->load->view('template/footer');
    }

    public function warehouse_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['warehouse'] = $this->super_model->select_all('warehouse');
        $this->load->view('masterfile/warehouse_list',$data);
        $this->load->view('template/footer');
    }

    public function employee_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['employee'] = $this->super_model->select_all('employees');
        $this->load->view('masterfile/employee_list',$data);
        $this->load->view('template/footer');
    }

    public function purpose_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['purpose'] = $this->super_model->select_all('purpose');
        $this->load->view('masterfile/purpose_list',$data);
        $this->load->view('template/footer');
    }

    public function view_cat(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['cat'] = $this->super_model->select_row_where('item_categories', 'cat_id', $id);
        $this->load->view('template/header');
       /* $data['category'] = $this->super_model->select_all('item_categories');*/
        $this->load->view('masterfile/view_cat',$data);
    }

    public function group_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['group'] = $this->super_model->select_all('group');
        $this->load->view('masterfile/group_list',$data);
        $this->load->view('template/footer');
    }

    public function subcat_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $this->load->view('masterfile/subcat_list',$data);
        $this->load->view('template/footer');
    }

    public function signatory(){
        
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/signatory');
        $this->load->view('template/footer');
    }

    public function add_signatory(){
        //$data['employee'] = $this->super_model->select_all('employees');
        foreach($this->super_model->select_all('employees') AS $emp){
            $data['employee'][] = array(
                'employeeid'=>$emp->employee_id,
                'employee'=>$emp->employee_name
            );
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/add_signatory',$data);
        $this->load->view('template/footer');
    }

    public function insert_signatory(){
        $counter = $this->input->post('counter');
        for($x=0;$x<=$counter;$x++){
            $data = array(
                'employee_id'=>$this->input->post('employee_id'),
                'requested'=>$this->input->post('requested['.$x.']'),
                'noted'=>$this->input->post('noted['.$x.']'),
                'inspected'=>$this->input->post('inspected['.$x.']'),
                'delivered'=>$this->input->post('delivered['.$x.']'),
                'reviewed'=>$this->input->post('reviewed['.$x.']'),
                'received'=>$this->input->post('received['.$x.']'),
                'released'=>$this->input->post('released['.$x.']'),
                'approved'=>$this->input->post('approved['.$x.']')
            );
             $this->super_model->insert_into("signatories", $data);
        }
    }

    public function addSignatory(){
         $data = array(
            'form'=>$this->input->post('form'),
            'action'=>$this->input->post('action'),
            'employee_id'=>$this->input->post('employee')
        );
        if($this->super_model->insert_into("signatories", $data)){
           echo "<script>alert('Signatory successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/signatory'; </script>";
         }
    }

    public function add_list(){
        $supplier_code = trim($this->input->post('supplier_code'), " ");
        $supplier_name = trim($this->input->post('supplier_name'), " ");
        $address = trim($this->input->post('address'), " ");
        $contact_number = trim($this->input->post('contact_number'), " ");
        $terms = trim($this->input->post('terms'), " ");
        $data = array(
            'supplier_code'=>$supplier_code,
            'supplier_name'=>$supplier_name,
            'address'=>$address,
            'contact_number'=>$contact_number,
            'terms'=>$terms,
            'active'=>$this->input->post('active')
        );
       if($this->super_model->insert_into("supplier", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/supplier_list'; </script>";
       }
    }

    public function add_department(){
        $trim = trim($this->input->post('department')," ");
        $data = array(
            'department_name'=>$trim
        );
       if($this->super_model->insert_into("department", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/department_list'; </script>";
       }
    }

    public function add_employee(){
        $trim = trim($this->input->post('employee_name')," ");
        $data = array(
            'employee_name'=>$trim
        );
       if($this->super_model->insert_into("employees", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/employee_list'; </script>";
       }
    }

    public function add_warehouse(){
        $warehouse_name = trim($this->input->post('warehouse_name')," ");
        $data = array(
            'warehouse_name'=>$warehouse_name
        );
       if($this->super_model->insert_into("warehouse", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/warehouse_list'; </script>";
       }
    }

    public function add_location(){
        $location = trim($this->input->post('location')," ");
        $data = array(
            'location_name'=>$location
        );
       if($this->super_model->insert_into("location", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/location_list'; </script>";
       }
    }

    public function add_group(){
        $group = trim($this->input->post('group_name')," ");
        $data = array(
            'group_name'=>$group
        );
       if($this->super_model->insert_into("group", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/group_list'; </script>";
       }
    }

    public function add_enduse(){
        $endc = trim($this->input->post('end_code')," ");
        $endn = trim($this->input->post('end_name')," ");
        $data = array(
            'enduse_code'=>$endc,
            'enduse_name'=>$endn
        );
       if($this->super_model->insert_into("enduse", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/endUse_list'; </script>";
       }
    }

    public function add_purpose(){
        $purpose = trim($this->input->post('purpose')," ");
        $data = array(
            'purpose_desc'=>$purpose
        );
       if($this->super_model->insert_into("purpose", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/purpose_list'; </script>";
       }
    }

    public function add_category(){
        $rows = $this->super_model->count_rows("item_categories");
        if($rows==0) {
            $cat_code = 'A';
            for ($n=0; $n<0; $n++) {
                echo $cat_code++;
            }
        }
        else{
             $cat_code = $this->super_model->get_max('item_categories', 'cat_code');
             $cat_code++;
        }
        $prefix = trim($this->input->post('prefix')," ");
        $cat_name = trim($this->input->post('category_name')," ");
        $data = array(
            'cat_code'=> $cat_code,
            'cat_prefix'=>$prefix,
            'cat_name'=>$cat_name
        );
        if($this->super_model->insert_into("item_categories", $data)){
           echo "<script>alert('Successfully Added!'); 
                window.location ='".base_url()."index.php/masterfile/category_list'; </script>";
        }
    }

    public function add_subcat(){
        $post = $this->input->post('id');
        $row = $this->super_model->count_rows_where("item_subcat", "cat_id", $post);
        if($row==0){
            $add = 1;
            $subcat_code = $this->input->post('cat_code')."-".$add;
        }   
        else {
            $subcat_code = $this->super_model->get_max_where("item_subcat", "subcat_code","cat_id = '$post' ORDER BY subcat_id DESC LIMIT 1");
            $array = explode("-", $subcat_code);
            $inc = $array[1]+1;
            $subcat_code = $array[0]."-".$inc;
        }
        $prefix = trim($this->input->post('prefix')," ");
        $sub_name = trim($this->input->post('subcategory_name')," ");
        $data = array(
            'cat_id'=>$this->input->post('id'),
            'subcat_code'=>$subcat_code,
            'subcat_prefix'=>$prefix,
            'subcat_name'=> $sub_name
        );
        if($this->super_model->insert_into("item_subcat", $data)){
           echo "<script>alert('Successfully Added!'); window.opener.location.reload(); window.close();</script>";
        }
    }

    public function update_signatory(){
         $data = array(
            'form'=>$this->input->post('form'),
            'action'=>$this->input->post('action'),
            'employee_id'=>$this->input->post('employee'),
        );
        $signid = $this->input->post('signid');
            if($this->super_model->update_where('signatories', $data, 'signatory_id', $signid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/signatory'; </script>";
        }
    }

    public function update_supplier(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['list'] = $this->super_model->select_row_where('supplier', 'supplier_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_supplier',$data);
        $this->load->view('template/footer');
    }

    public function update_warehouse(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['warehouse'] = $this->super_model->select_row_where('warehouse', 'warehouse_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_warehouse',$data);
        $this->load->view('template/footer');
    }

    public function edit_warehouse(){
        $data = array(
            'warehouse_name'=>$this->input->post('warehouse')
        );
        $warehouse_id = $this->input->post('warehouse_id');
            if($this->super_model->update_where('warehouse', $data, 'warehouse_id', $warehouse_id)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/warehouse_list'; </script>";
        }
    }

    public function update_employee(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['employee'] = $this->super_model->select_row_where('employees', 'employee_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_employee',$data);
        $this->load->view('template/footer');
    }

    public function edit_employee(){
        $data = array(
            'employee_name'=>$this->input->post('employee')
        );
        $employee_id = $this->input->post('employee_id');
            if($this->super_model->update_where('employees', $data, 'employee_id', $employee_id)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/employee_list'; </script>";
        }
    }

    public function update_list(){
        $data = array(
            'supplier_code'=>$this->input->post('supplier_code'),
            'supplier_name'=>$this->input->post('supplier_name'),
            'address'=>$this->input->post('address'),
            'contact_number'=>$this->input->post('contact_number'),
            'terms'=>$this->input->post('terms'),
            'active'=>$this->input->post('active')
        );
        $supid = $this->input->post('supplier_id');
            if($this->super_model->update_where('supplier', $data, 'supplier_id', $supid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/supplier_list'; </script>";
        }
    }

    public function update_category(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['category'] = $this->super_model->select_row_where('item_categories', 'cat_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_category',$data);
        $this->load->view('template/footer');
    }

    public function edit_category(){
        $data = array(
            'cat_prefix'=>$this->input->post('prefix'),
            'cat_name'=>$this->input->post('cat_name')
        );
        $catid = $this->input->post('cat_id');
            if($this->super_model->update_where('item_categories', $data, 'cat_id', $catid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/category_list'; </script>";
        }
    }

    public function update_department(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['department'] = $this->super_model->select_row_where('department', 'department_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_department',$data);
        $this->load->view('template/footer');
    }

    public function edit_department(){
        $data = array(
            'department_name'=>$this->input->post('department')
        );
        $depid = $this->input->post('department_id');
            if($this->super_model->update_where('department', $data, 'department_id', $depid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/department_list'; </script>";
        }
    }

    public function update_location(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['location'] = $this->super_model->select_row_where('location', 'location_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_location',$data);
        $this->load->view('template/footer');
    }

    public function edit_location(){
        $data = array(
            'location_name'=>$this->input->post('location')
        );
        $locid = $this->input->post('location_id');
            if($this->super_model->update_where('location', $data, 'location_id', $locid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/location_list'; </script>";
        }
    }


    public function update_group(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['group'] = $this->super_model->select_row_where('group', 'group_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_group',$data);
        $this->load->view('template/footer');
    }

    public function edit_group(){
        $data = array(
            'group_name'=>$this->input->post('group_name')
        );
        $grpid = $this->input->post('group_id');
            if($this->super_model->update_where('group', $data, 'group_id', $grpid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/group_list'; </script>";
        }
    }

    public function update_end(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['enduse'] = $this->super_model->select_row_where('enduse', 'enduse_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_end',$data);
        $this->load->view('template/footer');
    }

    public function edit_end(){
        $data = array(
            'enduse_code'=>$this->input->post('end_code'),
            'enduse_name'=>$this->input->post('end_name')
        );
        $endid = $this->input->post('enduse_id');
            if($this->super_model->update_where('enduse', $data, 'enduse_id', $endid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/endUse_list'; </script>";
        }
    }

    public function update_purpose(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $data['purpose'] = $this->super_model->select_row_where('purpose', 'purpose_id', $id);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/update_purpose',$data);
        $this->load->view('template/footer');
    }

    public function edit_purpose(){
        $data = array(
            'purpose_desc'=>$this->input->post('purpose'),
        );
        $purid = $this->input->post('purpose_id');
            if($this->super_model->update_where('purpose', $data, 'purpose_id', $purid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/masterfile/purpose_list'; </script>";
        }
    }

    public function delete_category(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('item_categories', 'cat_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/category_list'; </script>";
        }
    }

    public function delete_list(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('supplier', 'supplier_id', $id)){
            echo "<script>alert('Succesfully deleted'); 
                window.location ='".base_url()."index.php/masterfile/supplier_list'; </script>";
        }
    }

    public function delete_department(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('department', 'department_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/department_list'; </script>";
        }
    }
    public function delete_employee(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('employees', 'employee_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/employee_list'; </script>";
        }
    }
    public function delete_warehouse(){
        $id=$this->uri->segment(3);
     
        if($this->super_model->delete_where('warehouse', 'warehouse_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/warehouse_list'; </script>";
        }
    }

    public function delete_location(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('location', 'location_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/location_list'; </script>";
        }
    }

    public function delete_group(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('group', 'group_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/group_list'; </script>";
        }
    }

    public function delete_end(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('enduse', 'enduse_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/endUse_list'; </script>";
        }
    }

    public function delete_purpose(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('purpose', 'purpose_id', $id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/masterfile/purpose_list'; </script>";
        }
    }

    public function delete_sign(){
        $id=$this->uri->segment(3);
        if($this->super_model->delete_where('signatories', 'signatory_id', $id)){
            echo "<script>alert('Succesfully deleted'); 
                window.location ='".base_url()."index.php/masterfile/signatory'; </script>";
        }
    }


     public function import_items(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('masterfile/import_items');
        $this->load->view('template/footer');
    }

    public function upload_excel(){
         $dest= realpath(APPPATH . '../uploads/excel/');
         $error_ext=0;
        if(!empty($_FILES['excelfile']['name'])){
            $exc= basename($_FILES['excelfile']['name']);
            $exc=explode('.',$exc);
            $ext1=$exc[1];
            if($ext1=='php' || $ext1!='xlsx'){
                $error_ext++;
            } 
            else {
                $filename1='item_inventory.'.$ext1;
                if(move_uploaded_file($_FILES["excelfile"]['tmp_name'], $dest.'/'.$filename1)){
                    $this->readExcel_inv();
                }        
            }
        }
    }

    public function readExcel_inv(){
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $inputFileName =realpath(APPPATH.'../uploads/excel/item_inventory.xlsx');
        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } 
        catch(Exception $e) {
            die('Error loading file"'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
        }
        $highestRow = $objPHPExcel->getActiveSheet()->getHighestRow(); 
        for($x=2;$x<=$highestRow;$x++){
            $desc = $objPHPExcel->getActiveSheet()->getCell('A'.$x)->getValue();
            $cat_id = trim($objPHPExcel->getActiveSheet()->getCell('B'.$x)->getValue());
            $subcat_id = trim($objPHPExcel->getActiveSheet()->getCell('C'.$x)->getValue());
            $prefix = trim($objPHPExcel->getActiveSheet()->getCell('D'.$x)->getValue());
            $unit = trim($objPHPExcel->getActiveSheet()->getCell('E'.$x)->getValue());
            $pn = trim($objPHPExcel->getActiveSheet()->getCell('F'.$x)->getValue());
            if(empty($pn)){
                $count=$this->super_model->count_rows_where("pn_series","subcat_prefix",$prefix);
                if($count==0){
                    $newpn='1001';
                    $orig_pn = $prefix."_".$newpn;
                } else {
                    $maxid=$this->super_model->get_max_where("pn_series", "series", "subcat_prefix = '$prefix'");
                    $newpn=$maxid+1;
                    $orig_pn = $prefix."_".$newpn;
                }
                $data_pn = array(
                    'subcat_prefix'=>$prefix,
                    'series'=>$newpn
                );
                $this->super_model->insert_into("pn_series", $data_pn);
                $data_items = array(
                    'item_name'=>$desc,
                    'category_id'=>$cat_id,
                    'subcat_id'=>$subcat_id,
                    'unit'=>$unit,
                    'original_pn'=>$orig_pn
                );
                $this->super_model->insert_into("items", $data_items);
            } 
            else {
                $data_items = array(
                    'item_name'=>$desc,
                    'category_id'=>$cat_id,
                    'subcat_id'=>$subcat_id,
                    'unit'=>$unit,
                    'original_pn'=>$pn
                );
                $this->super_model->insert_into("items", $data_items);
            }
        }
        echo "<script>alert('Successfully uploaded!'); window.location = 'import_items';</script>";
    }
     
    
    public function export_begbal(){
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $exportfilename="begbal_format.xlsx";
       
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', "Item ID");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1', "Item Description");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', "Remarks");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D1', "Quantity");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I1', "Instructions:");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I2', "Just fill out quantity column. Do not edit other columns.");
        $num=2;
        foreach($this->super_model->select_all("items") AS $items){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $items->item_id);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $items->item_name);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$num, 'begbal');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, '');
            $num++;
        }
        $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if (file_exists($exportfilename))
        unlink($exportfilename);
        $objWriter->save($exportfilename);
        unset($objPHPExcel);
        unset($objWriter);   
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="begbal_format.xlsx"');
        readfile($exportfilename);
        echo "<script>window.location = 'import_items';</script>";
    }

    public function upload_excel_begbal(){
         $dest= realpath(APPPATH . '../uploads/excel/');
         $error_ext=0;
        if(!empty($_FILES['excelfile_begbal']['name'])){
             $exc= basename($_FILES['excelfile_begbal']['name']);
             $exc=explode('.',$exc);
             $ext1=$exc[1];
            if($ext1=='php' || $ext1!='xlsx'){
                $error_ext++;
            } 
            else {
                 $filename1='beginning_bal.'.$ext1;
                if(move_uploaded_file($_FILES["excelfile_begbal"]['tmp_name'], $dest.'/'.$filename1)){
                    $this->readExcel_begbal();
                }   
            }
        }
    }

    public function readExcel_begbal(){
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $inputFileName =realpath(APPPATH.'../uploads/excel/beginning_bal.xlsx');
        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch(Exception $e) {
            die('Error loading file"'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
        }

        $highestRow = $objPHPExcel->getActiveSheet()->getHighestRow(); 
        for($x=2;$x<=$highestRow;$x++){
            $itemid = trim($objPHPExcel->getActiveSheet()->getCell('A'.$x)->getValue());
            $catalog = trim($objPHPExcel->getActiveSheet()->getCell('C'.$x)->getValue());
            $qty = trim($objPHPExcel->getActiveSheet()->getCell('D'.$x)->getValue());
            $count=$this->super_model->count_rows_where("supplier_items","item_id",$itemid);
            if($count!=0){
                $this->super_model->delete_where("supplier_items", "item_id",$itemid);
            }
            $data_items = array(
                'item_id'=>$itemid,
                'catalog_no'=>$catalog,
                'quantity'=>$qty
            );
            $this->super_model->insert_into("supplier_items", $data_items);
        }
        echo "<script>alert('Successfully uploaded!'); window.location = 'import_items';</script>";
    }
}
?>
