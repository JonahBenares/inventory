<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Request extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');

        date_default_timezone_set("Asia/Manila");
        $this->load->model('super_model');
        $this->dropdown['department'] = $this->super_model->select_all_order_by('department', 'department_name', 'ASC');
        $this->dropdown['purpose'] = $this->super_model->select_all_order_by('purpose', 'purpose_desc', 'ASC');
        $this->dropdown['enduse'] = $this->super_model->select_all_order_by('enduse', 'enduse_name', 'ASC');
         $this->dropdown['prno'] = $this->super_model->select_join_where("receive_details","receive_head", "saved='1' AND create_date BETWEEN CURDATE() - INTERVAL 60 DAY AND CURDATE()","receive_id");
        function arrayToObject($array){
            if(!is_array($array)) { return $array; }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) { $object->$name = arrayToObject($value); }
                }
                return $object;
            } else {
                return false;
            }
        }
    }

    public function insert_request_head(){

        $year=date('Y-m');
        $now=date('Y-m-d H:i:s');
        $rows=$this->super_model->count_custom_where("request_head","request_date LIKE '$year%'");
        if($rows==0){
             $newreq_no = "MreqF-".$year."-0001";
        } else {
            $maxreqno=$this->super_model->get_max_where("request_head", "mreqf_no","request_date LIKE '$year%'");
            $reqno = explode('-',$maxreqno);
            $series = $reqno[3]+1;
            if(strlen($series)==1){
                $newreq_no = "MreqF-".$year."-000".$series;
            } else if(strlen($series)==2){
                 $newreq_no = "MreqF-".$year."-00".$series;
            } else if(strlen($series)==3){
                 $newreq_no = "MreqF-".$year."-0".$series;
            } else if(strlen($series)==4){
                 $newreq_no = "MreqF-".$year."-".$series;
            }
        }

         $head_rows = $this->super_model->count_rows("request_head");
        if($head_rows==0){
            $requestid=1;
        } else {
            $maxid=$this->super_model->get_max("request_head", "request_id");
            $requestid=$maxid+1;
        }

        $data = array(
           'request_id'=>$requestid,
           'create_date'=> $now,
           'request_date'=> $this->input->post('request_date'),
           'request_time'=> $this->input->post('request_time'),
           'mreqf_no'=> $newreq_no,
           'department_id'=> $this->input->post('department'),
           'purpose_id'=> $this->input->post('purpose'),
           'enduse_id'=> $this->input->post('enduse'),
           'pr_no'=> $this->input->post('prno'),
           'borrowfrom_pr'=> $this->input->post('borrow_pr'),
           'remarks'=> $this->input->post('remarks'),
           'user_id'=> $this->input->post('userid')
        );

        if($this->super_model->insert_into("request_head", $data)){
             redirect(base_url().'index.php/request/add_request/'.$requestid);
        }
    }

    public function request_list(){
        foreach($this->super_model->select_all("request_head") AS $request){
            $department = $this->super_model->select_column_where("department", "department_name", "department_id", $request->department_id);
            $purpose = $this->super_model->select_column_where("purpose", "purpose_desc", "purpose_id", $request->purpose_id);
            $enduse = $this->super_model->select_column_where("enduse", "enduse_name", "enduse_id", $request->enduse_id);
            $data['request'][] = array(
                'requestid'=>$request->request_id,
                'mreqf'=>$request->mreqf_no,
                'prno'=>$request->pr_no,
                'date'=>$request->request_date,
                'department'=>$department,
                'purpose'=>$purpose,
                'enduse'=>$enduse
            );
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('request/request_list',$data);
        $this->load->view('template/footer');
    }

    public function view_request(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $this->load->model('super_model');
        $data['head'] = $this->super_model->select_row_where('request_head', 'request_id', $id);
        
        foreach($this->super_model->select_row_where('request_head','request_id', $id) AS $req){
            foreach($this->super_model->select_row_where('request_items','request_id', $req->request_id) AS $rt){
                $item = $this->super_model->select_column_where("items", "item_name", "item_id", $rt->item_id);
                $rec_qty = $this->super_model->select_sum("supplier_items", "quantity", "item_id", $rt->item_id);
                $data['req_itm'][] = array(
                    'item'=>$item,
                    'qty'=>$rt->quantity,
                    'uom'=>$rt->uom,
                    'pn'=>$rt->pn_no,
                    'invqty'=>$rec_qty
                );
            }
            $department = $this->super_model->select_column_where("department", "department_name", "department_id", $req->department_id);
            $purpose = $this->super_model->select_column_where("purpose", "purpose_desc", "purpose_id", $req->purpose_id);
            $enduse = $this->super_model->select_column_where("enduse", "enduse_name", "enduse_id", $req->enduse_id);
            $data['req'][] = array(
                'requestid'=>$req->request_id,
                'mreqf'=>$req->mreqf_no,
                'prno'=>$req->pr_no,
                'date'=>$req->request_date,
                'time'=>$req->request_time,
                'department'=>$department,
                'purpose'=>$purpose,
                'enduse'=>$enduse,
                'remarks'=>$req->remarks
            );
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('request/view_request',$data);
        $this->load->view('template/footer');
    }

    public function mreqf(){
        $id=$this->uri->segment(3);
        foreach($this->super_model->select_row_where('request_head','request_id', $id) AS $req){
            foreach($this->super_model->select_row_where('request_items','request_id', $req->request_id) AS $rt){
                $item = $this->super_model->select_column_where("items", "item_name", "item_id", $rt->item_id);
                $rec_qty = $this->super_model->select_sum("supplier_items", "quantity", "item_id", $rt->item_id);
                $data['req_itm'][] = array(
                    'item'=>$item,
                    'qty'=>$rt->quantity,
                    'uom'=>$rt->uom,
                    'pn'=>$rt->pn_no,
                    'invqty'=>$rec_qty
                );
            }
            $department = $this->super_model->select_column_where("department", "department_name", "department_id", $req->department_id);
            $purpose = $this->super_model->select_column_where("purpose", "purpose_desc", "purpose_id", $req->purpose_id);
            $enduse = $this->super_model->select_column_where("enduse", "enduse_name", "enduse_id", $req->enduse_id);
            $data['req'][] = array(
                'requestid'=>$req->request_id,
                'mreqf'=>$req->mreqf_no,
                'prno'=>$req->pr_no,
                'date'=>$req->request_date,
                'time'=>$req->request_time,
                'department'=>$department,
                'purpose'=>$purpose,
                'enduse'=>$enduse,
                'remarks'=>$req->remarks
            );
        }
        $this->load->view('template/header');
        $this->load->view('request/mreqf',$data);
    }


    public function add_request(){
        $id=$this->uri->segment(3);
        $data['requestid']= $id;
        $data['request']= $id;
        foreach($this->super_model->select_row_where("request_head", "request_id", $id) AS $req){
            $data['head'][]=array(
                "mreqf_no"=>$req->mreqf_no,
                "request_date"=>$req->request_date,
                "request_time"=>$req->request_time,
                "department"=>$this->super_model->select_column_where("department", "department_name", "department_id", $req->department_id),
                "purpose"=>$this->super_model->select_column_where("purpose", "purpose_desc", "purpose_id", $req->purpose_id),
                "enduse"=>$this->super_model->select_column_where("enduse", "enduse_name", "enduse_id", $req->enduse_id),
                "department"=>$this->super_model->select_column_where("department", "department_name", "department_id", $req->department_id),
                "department"=>$this->super_model->select_column_where("department", "department_name", "department_id", $req->department_id),
                "prno"=>$req->pr_no,
                "remarks"=>$req->remarks,
            );
        }
        $row1=$this->super_model->count_rows_where("request_items","request_id",$id);
        if($row1!=0){
            foreach($this->super_model->select_row_where('request_items','request_id', $id) AS $rt){
                $item = $this->super_model->select_column_where("items", "item_name", "item_id", $rt->item_id);
                $rec_qty = $this->super_model->select_sum("supplier_items", "quantity", "item_id", $rt->item_id);
                $data['req_itm'][] = array(
                    'itemid'=>$rt->request_id,
                    'item'=>$item,
                    'qty'=>$rt->quantity,
                    'uom'=>$rt->uom,
                    'pn'=>$rt->pn_no,
                    'invqty'=>$rec_qty,
                );
            }
        }else{
            $data['req_itm'] = array();
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('request/add_request',$data);
        $this->load->view('template/footer');
    }

    public function insertRequest(){
        $counter = $this->input->post('counter');
        $id=$this->input->post('requestid');
        for($a=0;$a<$counter;$a++){
            if(!empty($this->input->post('item_id['.$a.']'))){
                $data = array(
                    'request_id'=>$this->input->post('requestid'),
                    'item_id'=>$this->input->post('item_id['.$a.']'),
                    'quantity'=>$this->input->post('quantity['.$a.']'),
                    'uom'=>$this->input->post('unit['.$a.']'),
                    'pn_no'=>$this->input->post('original_pn['.$a.']'),
                    'si_id'=>$this->input->post('siid['.$a.']'),
                    'supplier_id'=>$this->input->post('supplier_id['.$a.']'),
                    'catalog_no'=>$this->input->post('catalog_no['.$a.']'),
                    'brand_id'=>$this->input->post('brand_id['.$a.']')
                );
                $this->super_model->insert_into("request_items", $data); 
            }
        }
        echo $id;
    }


     public function itemlist(){
        $item=$this->input->post('item');
        $original_pn=$this->input->post('original_pn');
        $rows=$this->super_model->count_custom_where("items","item_name LIKE '%$item%' OR original_pn LIKE '%$original_pn%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("items", "item_name LIKE '%$item%' OR original_pn LIKE '%$original_pn%'") AS $itm){ 
                    $name = str_replace('"', '', $itm->item_name);

                    $rec_qty = $this->super_model->select_sum("supplier_items", "quantity", "item_id", $itm->item_id);
                    ?>
                   <li onClick="selectItem('<?php echo $itm->item_id; ?>','<?php echo $name; ?>','<?php echo $itm->unit; ?>','<?php echo $itm->original_pn;?>','<?php echo $rec_qty;?>')"><strong><?php echo $itm->original_pn;?> - </strong> <?php echo $name; ?></li>
                <?php 
            }
             echo "<ul>";
        }
        
    }


    public function crossreflist(){
        $item=$this->input->post('item');
        $rows=$this->super_model->count_custom_where("supplier_items","item_id = '$item'");
        if($rows!=0){
            echo "<select name='siid' id='siid' class='form-control'>";
            echo "<option value=''>-Cross Reference-</option>";
            foreach($this->super_model->select_custom_where("supplier_items","item_id = '$item' AND quantity != '0'") AS $itm){ 
                    $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $itm->brand_id);
                    $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $itm->supplier_id);
                    ?>
                    <option value="<?php echo $itm->si_id; ?>"><?php echo $supplier . " - " . $itm->catalog_no . " - ". $brand . " (".$itm->quantity.")"; ?></option>
                <?php 
            }
            echo "</select>";
        }
        
    }

    public function getitem(){
        foreach($this->super_model->select_row_where("supplier_items", "si_id", $this->input->post('siid')) AS $si){
             $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $si->brand_id);
             $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $si->supplier_id);
             $supplier_id = $si->supplier_id;
             $brand_id=$si->brand_id;
             $catalog_no = $si->catalog_no;
             $invqty = $si->quantity;
            }
      

       $data['list'] = array(
            'original_pn'=>$this->input->post('original_pn'),
            'unit'=>$this->input->post('unit'),
            'itemid'=>$this->input->post('itemid'),
            'siid'=>$this->input->post('siid'),
            'brand'=>$brand,
            'brand_id'=>$brand_id,
            'supplier_id'=>$supplier_id,
            'supplier'=>$supplier,
            'catalog_no'=>$catalog_no,
            'invqty'=>$invqty,
            'quantity'=>$this->input->post('quantity'),
            'item'=>$this->input->post('item'),
            'count'=>$this->input->post('count')
        );
            
        $this->load->view('request/row_item',$data);
     }
}
?>
