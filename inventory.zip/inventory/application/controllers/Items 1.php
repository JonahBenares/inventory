<?php
defined('BASEPATH') OR exit('No direct script access allowed');

ini_set('max_execution_time', 0);
ini_set('memory_limit', '2048M');

class Items extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');

        date_default_timezone_set("Asia/Manila");
        $this->load->model('super_model');
        $this->dropdown['department'] = $this->super_model->select_all_order_by('department', 'department_name', 'ASC');
        $this->dropdown['purpose'] = $this->super_model->select_all_order_by('purpose', 'purpose_desc', 'ASC');
        $this->dropdown['enduse'] = $this->super_model->select_all_order_by('enduse', 'enduse_name', 'ASC');
      //  $this->dropdown['prno'] = $this->super_model->select_join_where_order("receive_details","receive_head", "saved='1'","receive_id", "receive_date", "DESC");

        
        foreach($this->super_model->select_row_where("receive_details", "closed", "0") AS $dtls){
            foreach($this->super_model->select_custom_where("receive_head", "receive_id = '$dtls->receive_id'") AS $gt){
               if($gt->saved=='1'){
                    $this->dropdown['prno'][] = $dtls->pr_no;
               }
            }  
        }
        function arrayToObject($array){
            if(!is_array($array)) { return $array; }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) { $object->$name = arrayToObject($value); }
                }
                return $object;
            } else {
                return false;
            }
        }
    }

    public function index(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('items/login');
        $this->load->view('template/footer');
    }

    public function item_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        
        $data['category'] = $this->super_model->select_all('item_categories');
        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $data['group'] = $this->super_model->select_all('group');
        $data['location'] = $this->super_model->select_all('location');
        $data['warehouse'] = $this->super_model->select_all('warehouse');
        $data['bin'] = $this->super_model->select_all('bin');
        $row=$this->super_model->count_rows("items");
        if($row!=0){
            foreach($this->super_model->select_all('items') AS $itm){
                $bin = $this->super_model->select_column_where('bin', 'bin_name', 
                    'bin_id', $itm->bin_id);
                $warehouse = $this->super_model->select_column_where('warehouse', 'warehouse_name', 
                    'warehouse_id', $itm->warehouse_id);
               // $totalqty=$this->super_model->select_sum("supplier_items", "quantity", "item_id", $itm->item_id);
                $totalqty=$this->inventory_balance($itm->item_id);
                $data['items'][] = array(
                    'item_id'=>$itm->item_id,
                    'original_pn'=>$itm->original_pn,
                    'item_name'=>$itm->item_name,
                    'category'=>$this->super_model->select_column_where('item_categories', 'cat_name', 
                    'cat_id', $itm->category_id),
                    'subcategory'=>$this->super_model->select_column_where('item_subcat', 'subcat_name', 
                    'subcat_id', $itm->subcat_id),
                    'quantity'=>$totalqty,
                    'bin'=>$bin,
                    'warehouse'=>$warehouse,
                    'minimum'=>$itm->min_qty
                );
            }
        }else{
            $data['items'] = array();
        }
        $this->load->view('items/item_list',$data);
        $this->load->view('template/footer');
    }

     public function add_item_first(){

        $data['subcat'] = $this->super_model->select_all_order_by('item_subcat', 'subcat_name', 'ASC');
        $data['group'] = $this->super_model->select_all_order_by('group','group_name','ASC');
        $data['location'] = $this->super_model->select_all_order_by('location','location_name','ASC');
        $data['warehouse'] = $this->super_model->select_all_order_by('warehouse','warehouse_name','ASC');
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('items/add_item_first',$data);
        $this->load->view('template/footer');
    }
    public function add_item_second(){

        $id=$this->uri->segment(3);
        $data['id'] = $id;
        $data['item'] = $this->super_model->select_row_where("items", "item_id", $id);

        $row_sup=$this->super_model->count_rows_where("supplier_items","item_id", $id);

        if($row_sup!=0){
            foreach($this->super_model->select_row_where_order_by("supplier_items", "item_id", $id, "supplier_id", "ASC") AS $i){
                $data['supplier_item'][] = array(
                    "si_id"=>$i->si_id,
                    "supplier"=> $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $i->supplier_id),
                    "catalog"=>$i->catalog_no,
                    "brand"=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $i->brand_id),
                    "item_cost"=>$i->item_cost,
                    "quantity"=>$i->quantity,
                );
            }
        } else {
             $data['supplier_item'] = array();
        }

        $data['supplier'] = $this->super_model->select_all_order_by("supplier", "supplier_name", "ASC");
        
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('items/add_item_second',$data);
        $this->load->view('template/footer');
    }

    public function insert_supplier_item(){
        $item=$this->input->post('item');
        $supplier=$this->input->post('supplier');
        $catalog=$this->input->post('catalog');
        $brandid=$this->input->post('brandid');
        $brand=$this->input->post('brand');
        $cost=$this->input->post('cost');

        if(empty($brandid)){
           $maxid=$this->super_model->get_max("brand", "brand_id");
           $bid=$maxid+1;

           $brand_data = array(
                'brand_id' => $bid,
                'brand_name' => $brand
           );

           $this->super_model->insert_into("brand", $brand_data);

        } else {
           $bid = $brandid;
        }

        $item_data = array(
            'item_id'=> $item,
            'supplier_id'=>$supplier,
            'catalog_no'=>$catalog,
            'brand_id'=>$bid,
            'item_cost'=>$cost
        );
        if($this->super_model->insert_into("supplier_items", $item_data)){
            echo "success";
        } else {
            echo "error";
        }
       
    }

    public function update_item(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $data['items'] = $this->super_model->select_row_where('items', 'item_id', $id);

        $catid=$this->super_model->select_column_where("items", "category_id", "item_id", $id);
        $data['cat_name'] = $this->super_model->select_column_where("item_categories", "cat_name", "cat_id", $catid);

        $binid=$this->super_model->select_column_where("items", "bin_id", "item_id", $id);
        $data['bin_name'] = $this->super_model->select_column_where("bin", "bin_name", "bin_id", $binid);


        $orig_pn=$this->super_model->select_column_where("items", "original_pn", "item_id", $id);
        $pn_details=explode("_",$orig_pn);
        if(count($pn_details)<2){
            $prefix=0;
            $series=0;
        } else {
            $prefix=$pn_details[0];
            $series=$pn_details[1];
        }
        $row_count = $this->super_model->count_custom_where("pn_series","subcat_prefix='$prefix' AND series = '$series'");
        if($row_count==1){
            $data['pn_format']=1;
        } else {
            $data['pn_format']=0;
        }


        $data['subcat'] = $this->super_model->select_all_order_by('item_subcat', 'subcat_name', 'ASC');
        $data['group'] = $this->super_model->select_all_order_by('group','group_name','ASC');
        $data['location'] = $this->super_model->select_all_order_by('location','location_name','ASC');
        $data['warehouse'] = $this->super_model->select_all_order_by('warehouse','warehouse_name','ASC');
        $this->load->view('items/update_item',$data);
        $this->load->view('template/footer');
    }

    public function edit_item(){
        $data = array(
            'category_id'=>$this->input->post('category'),
            'subcat_id'=>$this->input->post('subcat'),
            'original_pn'=>$this->input->post('pn'),
            'item_name'=>$this->input->post('item_name'),
        );
        $itemid = $this->input->post('item_id');
            if($this->super_model->update_where('items', $data, 'item_id', $itemid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/items/item_list';</script>";
        }
    }

    /*public function view_item(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $this->load->model('super_model');
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $data['items'] = $this->super_model->select_row_where('items', 'item_id', $id);
        $this->load->view('items/view_item',$data);
        $this->load->view('template/footer');
    }*/

    public function inventory_balance($itemid){
         $recqty= $this->super_model->select_sum("supplier_items", "quantity", "item_id", $itemid);
      //   $issueqty= $this->super_model->select_sum_join("quantity","issuance_details","issuance_head", "item_id='$itemid' AND saved='1'","issuance_id");
         $issueqty= $this->super_model->select_sum("issuance_details","quantity", "item_id",$itemid);
         $balance=$recqty-$issueqty;
         return $balance;
    }

    public function crossref_balance($itemid,$supplierid,$brandid,$catalogno){
        $recqty= $this->super_model->select_sum_where("supplier_items", "quantity", "item_id = '$itemid' AND supplier_id = '$supplierid' AND brand_id = '$brandid' AND catalog_no ='$catalogno'");

        $issueqty= $this->super_model->select_sum_join("quantity","issuance_details","issuance_head", "item_id='$itemid' AND supplier_id = '$supplierid' AND brand_id = '$brandid' AND catalog_no = '$catalogno' AND saved='1'","issuance_id");
         $balance=$recqty-$issueqty;
         return $balance;
    }


    public function view_item_detail(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $row=$this->super_model->count_rows("items");
        $row1=$this->super_model->count_rows_where("supplier_items","item_id",$id);
        if($row1!=0){
          
            $data['total_qty']=$this->inventory_balance($id);

            foreach($this->super_model->select_row_where('supplier_items','item_id', $id) AS $sup){
                $count = $this->super_model->count_custom_where("supplier_items","item_id = '$id' AND supplier_id = '$sup->supplier_id' AND catalog_no = '$sup->catalog_no' AND brand_id = '$sup->brand_id'");
               
                if($count!=0){
                        $row=$this->super_model->count_rows("items");
                        unset($daterec);
                        foreach($this->super_model->select_custom_where("receive_items","item_id = '$sup->item_id' AND supplier_id = '$sup->supplier_id' AND catalog_no = '$sup->catalog_no' AND brand_id = '$sup->brand_id'") AS $rec){
                            $receivedate=$this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $rec->receive_id);
                            $daterec[]=$receivedate;
                        }

                        $balance= $this->crossref_balance($id,$sup->supplier_id,$sup->brand_id,$sup->catalog_no);
                        $date = max($daterec);
                        $data['supplier'][] = array( 
                            'item_id'=>$sup->item_id,
                            'supplier_id'=>$sup->supplier_id,
                            'brand_id'=>$sup->brand_id,
                            'catalog_no'=>$sup->catalog_no,
                            'item_cost'=>$sup->item_cost,
                            'quantity'=>$balance,
                            'supplier'=>$this->super_model->select_column_where('supplier', 'supplier_name','supplier_id', $sup->supplier_id),
                            'brand'=>$this->super_model->select_column_where('brand', 'brand_name','brand_id', $sup->brand_id),
                            'date'=>$date
                        );
                    
                } 
            } 
        }
        else{
        	$data['supplier'] = array();
        }
        
        if($row!=0){
            foreach($this->super_model->select_row_where('items', 'item_id', $id) AS $det){
                $nominal=$this->super_model->select_ave("supplier_items", "item_cost", "item_id", $det->item_id);
                $data['details'][] = array(
                    'item_id'=>$det->item_id,
                    'original_pn'=>$det->original_pn,
                    'item_name'=>$det->item_name,
                    'picture1'=>$det->picture1,
                    'picture2'=>$det->picture2,
                    'picture3'=>$det->picture3,
                    'unit'=>$det->unit,
                    'nominal'=>$nominal,
                    'category'=>$this->super_model->select_column_where('item_categories', 'cat_name', 
                    'cat_id', $det->category_id),
                    'subcategory'=>$this->super_model->select_column_where('item_subcat', 'subcat_name', 
                    'subcat_id', $det->subcat_id),
                    'group'=>$this->super_model->select_column_where('group', 'group_name', 
                    'group_id', $det->group_id),
                    'location'=>$this->super_model->select_column_where('location', 'location_name', 
                    'location_id', $det->location_id),
                    'bin'=>$this->super_model->select_column_where('bin', 'bin_name', 
                    'bin_id', $det->bin_id),
                    'warehouse'=>$this->super_model->select_column_where('warehouse', 'warehouse_name', 
                    'warehouse_id', $det->warehouse_id),
                    'rack'=>$det->rack,
                    'barcode'=>$det->barcode,
                    'expiration'=>$det->expiration,
                    'minimum'=>$det->min_qty,
                    'damage'=>$det->damage
                );
            }
        }else{
            $data['details'] = array();
        }
        $this->load->view('items/view_item_detail',$data);
        $this->load->view('template/footer');
    }

    public function getcategory(){
        $subcat = $this->input->post('subcat');
        $cat_id= $this->super_model->select_column_where('item_subcat', 'cat_id', 'subcat_id', $subcat);

        $subcat_prefix= $this->super_model->select_column_where('item_subcat', 'subcat_prefix', 'subcat_id', $subcat);
        $cat = $this->super_model->select_column_where('item_categories', 'cat_name', 'cat_id', $cat_id);

        $rows=$this->super_model->count_custom_where("pn_series","subcat_prefix = '$subcat_prefix'");

        if($rows==0){
            $pn_no= $subcat_prefix."_1001";
        } else {
            $series = $this->super_model->get_max_where("pn_series", "series","subcat_prefix = '$subcat_prefix'");
            $next=$series+1;
            $pn_no = $subcat_prefix."_".$next;
        }
        
        
        $return = array('catid' => $cat_id, 'cat' => $cat, 'pn' => $pn_no);
        echo json_encode($return);
    }

    public function getsubcat(){  
        $postData = $this->input->post();
        $data = $this->super_model->getsubcat($postData);
        echo json_encode($data); 
    }
    

    public function search(){
        $type=$this->input->post('type');
        
        if($type=='item'){
            $item_name=$this->input->post('itemname');   
            $this->load->model('item_model');
            return $this->item_model->select_item('items', "item_name = '$item_name'");
        } else if($type=='bin'){
            $bin_name=$this->input->post('binname');   
            $this->load->model('item_model');
            return $this->item_model->select_bin('bin', "bin_name LIKE '%$bin_name%'");
        } else if($type=='brand'){
            $brand_name=$this->input->post('brandname');   
           // echo $brand_name;
            $this->load->model('item_model');
            return $this->item_model->select_brand('brand', "brand_name LIKE '%$brand_name%'");
        }
    }

    public function insert_item(){
        $itemname=$this->input->post('item_name');
        $error_ext=0;
        $dest= realpath(APPPATH . '../uploads/');
        if(!empty($_FILES['img1']['name'])){
             $img1= basename($_FILES['img1']['name']);
             $img1=explode('.',$img1);
             $ext1=$img1[1];
            
            if($ext1=='php' || ($ext1!='png' && $ext1 != 'jpg' && $ext1!='jpeg')){
                $error_ext++;
            } else {
                 $filename1=$itemname.'1.'.$ext1;
                 move_uploaded_file($_FILES["img1"]['tmp_name'], $dest.'/'.$filename1);
            }

        } else {
            $filename1="";
        }

        if(!empty($_FILES['img2']['name'])){
             $img2= basename($_FILES['img2']['name']);
             $img2=explode('.',$img2);
             $ext2=$img2[1];
             
            if($ext2=='php' || ($ext2!='png' && $ext2 != 'jpg' && $ext2!='jpeg')){
                $error_ext++;
            } else {
                $filename2=$itemname.'2.'.$ext2;
                move_uploaded_file($_FILES["img2"]['tmp_name'], $dest.'/'.$filename2);
            }
        } else {
            $filename2="";
        }

        if(!empty($_FILES['img3']['name'])){
             $img3= basename($_FILES['img3']['name']);
             $img3=explode('.',$img3);
             $ext3=$img3[1];
            
            if($ext3=='php' || ($ext3!='png' && $ext3 != 'jpg' && $ext3!='jpeg')){
                $error_ext++;
            } else {
                $filename3=$itemname.'3.'.$ext3;
                move_uploaded_file($_FILES["img3"]['tmp_name'], $dest.'/'.$filename3);
            }
        } else {
            $filename3="";
        }

        if($error_ext!=0){
            echo "ext";
        } else {
             $binid= $this->input->post('binid');
             if(empty($binid)){
                $bin_name= $this->input->post('bin');

                
                $rows=$this->super_model->count_rows("bin");
                if($rows==0){
                    $bin = 1;
                } else {
                    $max=$this->super_model->get_max("bin", "bin_id");
                    $bin=$max+1;
                }

                $bindata = array(
                    'bin_id' => $bin,
                    'bin_name' => $bin_name
                );

                $this->super_model->insert_into("bin", $bindata);

             } else {
                $bin= $this->input->post('binid');
             }
      
            $row_items=$this->super_model->count_rows("items");
            if($row_items==0){
                $item_id=1;
            } else {
                 $maxid=$this->super_model->get_max("items", "item_id");
                 $item_id=$maxid+1;
            }

            $pnformat=$this->input->post('pnformat');

            if($pnformat==1){
                $pndetails=explode("_", $this->input->post('pn'));
                $subcat_prefix=$pndetails[0];
                $series = $pndetails[1];

                $pn_data= array(
                    'subcat_prefix'=>$subcat_prefix,
                    'series'=>$series
                );
                $this->super_model->insert_into("pn_series", $pn_data);
            }

              $data = array(
                    'item_id' => $item_id,
                    'category_id' => $this->input->post('cat'),
                    'subcat_id' => $this->input->post('subcat'),
                    'original_pn' => $this->input->post('pn'),
                    'item_name' => $this->input->post('item_name'),
                    'unit' => $this->input->post('unit'),
                    'group_id' => $this->input->post('group'),
                    'location_id' => $this->input->post('location'),
                    'warehouse_id' => $this->input->post('warehouse'),
                    'rack' => $this->input->post('rack'),
                    'barcode' => $this->input->post('barcode'),
                    'expiration' => $this->input->post('expiration'),
                    'damage' => $this->input->post('damage'),
                    'min_qty' => $this->input->post('minimum'),
                    'bin_id' => $bin,
                    'picture1' => $filename1,
                    'picture2' => $filename2,
                    'picture3' => $filename3
             );

              if($this->super_model->insert_into("items", $data)){
                echo $item_id;
              }
        }
    }

    public function savechanges_item(){
        $itemname=$this->input->post('item_name');
        $item_id=$this->input->post('item_id');
        $error_ext=0;
        $dest= realpath(APPPATH . '../uploads/');
        if(!empty($_FILES['img1']['name'])){
             $img1= basename($_FILES['img1']['name']);
             $img1=explode('.',$img1);
             $ext1=$img1[1];
            
            if($ext1=='php' || ($ext1!='png' && $ext1 != 'jpg' && $ext1!='jpeg')){
                $error_ext++;
            } else {
                 $filename1=$itemname.'1.'.$ext1;
                 move_uploaded_file($_FILES["img1"]['tmp_name'], $dest.'/'.$filename1);
                 $data_pic1 = array(
                    'picture1'=>$filename1
                 );
                 $this->super_model->update_where("items", $data_pic1, "item_id", $item_id);
            }

        }

        if(!empty($_FILES['img2']['name'])){
             $img2= basename($_FILES['img2']['name']);
             $img2=explode('.',$img2);
             $ext2=$img2[1];
             
            if($ext2=='php' || ($ext2!='png' && $ext2 != 'jpg' && $ext2!='jpeg')){
                $error_ext++;
            } else {
                $filename2=$itemname.'2.'.$ext2;
                move_uploaded_file($_FILES["img2"]['tmp_name'], $dest.'/'.$filename2);
                 $data_pic2 = array(
                    'picture2'=>$filename2
                 );
                 $this->super_model->update_where("items", $data_pic2, "item_id", $item_id);
            }
        } 

        if(!empty($_FILES['img3']['name'])){
             $img3= basename($_FILES['img3']['name']);
             $img3=explode('.',$img3);
             $ext3=$img3[1];
            
            if($ext3=='php' || ($ext3!='png' && $ext3 != 'jpg' && $ext3!='jpeg')){
                $error_ext++;
            } else {
                $filename3=$itemname.'3.'.$ext3;
                move_uploaded_file($_FILES["img3"]['tmp_name'], $dest.'/'.$filename3);
                $data_pic3 = array(
                    'picture3'=>$filename3
                 );
                 $this->super_model->update_where("items", $data_pic3, "item_id", $item_id);
            }
        } 
       
        if($error_ext!=0){
            echo "ext";
        } else {
            
             $binid= $this->input->post('binid');
             if(empty($binid)){
                $bin_name= $this->input->post('bin');

                
                $rows=$this->super_model->count_rows("bin");
                if($rows==0){
                    $bin = 1;
                } else {
                    $max=$this->super_model->get_max("bin", "bin_id");
                    $bin=$max+1;
                }

                $bindata = array(
                    'bin_id' => $bin,
                    'bin_name' => $bin_name
                );

                $this->super_model->insert_into("bin", $bindata);

             } else {
                $bin= $this->input->post('binid');
             }

            $pnformat=$this->input->post('pnformat');

            if($pnformat==1){
                $pndetails=explode("_", $this->input->post('pn'));
                $subcat_prefix=$pndetails[0];
                $series = $pndetails[1];

                $pn_data= array(
                    'subcat_prefix'=>$subcat_prefix,
                    'series'=>$series
                );
                $row_count = $this->super_model->count_custom_where("pn_series","subcat_prefix='$subcat_prefix' AND series = '$series'");
                if($row_count==0){
                    $this->super_model->insert_into("pn_series", $pn_data);
                }
            }   


              $data = array(
                    'category_id' => $this->input->post('cat'),
                    'subcat_id' => $this->input->post('subcat'),
                    'original_pn' => $this->input->post('pn'),
                    'item_name' => $this->input->post('item_name'),
                    'unit' => $this->input->post('unit'),
                    'group_id' => $this->input->post('group'),
                    'location_id' => $this->input->post('location'),
                    'bin_id' => $bin,
                    'warehouse_id' => $this->input->post('warehouse'),
                    'rack' => $this->input->post('rack'),
                    'barcode' => $this->input->post('barcode'),
                    'expiration' => $this->input->post('expiration'),
                    'damage' => $this->input->post('damage'),
                    'min_qty' => $this->input->post('minimum')
             );

              if($this->super_model->update_where("items", $data, "item_id", $item_id)){
                echo $item_id;
              }
        }
    }

    public function delete_supp_item(){
        $siid=$this->uri->segment(3);
        $id=$this->uri->segment(4);
        if($this->super_model->delete_where("supplier_items", "si_id", $siid)){
             redirect(base_url().'index.php/items/add_item_second/'.$id);
        }
        
        
    }

    public function count_supplier_item(){
        $item=$this->input->post('item');
        $supplier=$this->input->post('supplier');
        $catalog=$this->input->post('catalog');
        $brand=$this->input->post('brand');

        $row_items=$this->super_model->count_custom_where("supplier_items","item_id = '$item' AND supplier_id = '$supplier' AND catalog_no = '$catalog' AND brand_id = '$brand'");
        echo $row_items;
    }

    public function delete_item(){
        $id=$this->uri->segment(3);
        $this->load->model('super_model');
        if($this->super_model->delete_data($id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/items/item_list'; </script>";
        }
    }

    public function search_item(){
        $category=$this->input->post('category');
        $subcat=$this->input->post('subcat');
        $item_desc=$this->input->post('item_desc');
        $pn=$this->input->post('pn');
        $group=$this->input->post('group');
        $section=$this->input->post('section');
        $bin=$this->input->post('bin');
        $warehouse=$this->input->post('warehouse');
        $rack=$this->input->post('rack');
        $barcode=$this->input->post('barcode');
        $expiration=$this->input->post('expiration');
        $data['category'] = $this->super_model->select_all('item_categories');
        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $data['group'] = $this->super_model->select_all('group');
        $data['location'] = $this->super_model->select_all('location');
        $data['bin'] = $this->super_model->select_all('bin');

        $sql="";
        $filter ="";
        if(!empty($category)){
            $sql.= " items.category_id = '$category' AND";
            $filter.="Category = " . $this->super_model->select_column_where('item_categories', 'cat_name', 
                        'cat_id', $category). ", ";
        }

        if(!empty($subcat)){
            $sql.= " items.subcat_id = '$subcat' AND";
            $filter.="Sub category = " . $this->super_model->select_column_where('item_subcat', 'subcat_name', 
                        'subcat_id', $subcat) . ", ";
        }

        if(!empty($item_desc)){
            $sql.= " items.item_name LIKE '%$item_desc%' AND";
            $filter.="Item Desc = " .$item_desc. ", ";
        }

        if(!empty($pn)){
            $sql.= " items.original_pn LIKE '%$pn%' OR supplier_items.catalog_no LIKE '%$pn%' AND";
            $filter.="PN No. = " .$pn. ", ";
        }

        if(!empty($group)){
            $sql.= " items.group_id = '$group' AND";
            $filter.="Group = " . $this->super_model->select_column_where('group', 'group_name', 
                        'group_id', $group). ", ";
        }

        if(!empty($section)){
            $sql.= " items.location_id = '$section' AND";
            $filter.="Section = " . $this->super_model->select_column_where('location', 'location_name', 
                        'location_id', $section). ", ";
        }

        if(!empty($bin)){
            $sql.= " items.bin_id = '$bin' AND";
            $filter.="Bin = " . $this->super_model->select_column_where('bin', 'bin_name', 
                        'bin_id', $bin). ", ";
        }

        if(!empty($warehouse)){
            $sql.= " items.warehouse_id = '$warehouse' AND";
            $filter.="Warehouse = " . $this->super_model->select_column_where('warehouse', 'warehouse_name', 
                        'warehouse_id', $warehouse). ", ";
        }

        if(!empty($rack)){
            $sql.= " items.rack = '$rack' AND";
            $filter.="Rack = " .  $rack . ", ";
        }

        if(!empty($barcode)){
            $sql.= " items.barcode = '$barcode' AND";
            $filter.="Barcode = " .  $barcode . ", ";
        }

        if(!empty($expiration)){
            $sql.= " items.expiration = '$expiration' AND";
            $filter.="Expiration = " .  $expiration . ", ";
        }


        $query=substr($sql,0,-3);
        $filter=substr($filter,0,-2);
      
        $count=$this->super_model->count_join_where("items","supplier_items", $query, 'item_id');
       
        $data['filter']=$filter;
        if($count!=0){
            $data['count_query'] = 1;
            foreach($this->super_model->select_join_where("items", "supplier_items", $query, "item_id") AS $itm){
                $totalqty=$this->super_model->select_sum("supplier_items", "quantity", "item_id", $itm->item_id);
                 $data['items'][] = array(
                        'item_id'=>$itm->item_id,
                        'original_pn'=>$itm->original_pn,
                        'item_name'=>$itm->item_name,
                        'category'=>$this->super_model->select_column_where('item_categories', 'cat_name', 
                        'cat_id', $itm->category_id),
                        'subcategory'=>$this->super_model->select_column_where('item_subcat', 'subcat_name', 
                        'subcat_id', $itm->subcat_id),
                        'quantity'=>$totalqty
                    );
            }
        } else {
            $data['count_query'] = 0;
             $data['items']=array();
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('items/item_list',$data);
        $this->load->view('template/footer');
    }

    public function reportItem(){

        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('items/report_items');
        $this->load->view('template/footer');
    }
}

?>