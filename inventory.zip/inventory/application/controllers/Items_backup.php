<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Items extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');

        date_default_timezone_set("Asia/Manila");

        function arrayToObject($array){
            if(!is_array($array)) { return $array; }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) { $object->$name = arrayToObject($value); }
                }
                return $object;
            } else {
                return false;
            }
        }
    }

    public function index(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('items/login');
        $this->load->view('template/footer');
    }

    public function item_list(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->model('super_model');
        $row=$this->super_model->count_rows("items");
        if($row!=0){
            foreach($this->super_model->select_all('items') AS $itm){
                $data['items'][] = array(
                    'item_id'=>$itm->item_id,
                    'original_pn'=>$itm->original_pn,
                    'item_name'=>$itm->item_name,
                    'category'=>$this->super_model->select_column_where('item_categories', 'cat_name', 
                    'cat_id', $itm->category_id),
                    'subcategory'=>$this->super_model->select_column_where('item_subcat', 'subcat_name', 
                    'subcat_id', $itm->subcat_id)
                );
            }
        }else{
            $data['items'] = array();
        }
        $this->load->view('items/item_list',$data);
        $this->load->view('template/footer');
    }

     public function add_item_first(){

        $this->load->model('super_model');

        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $data['group'] = $this->super_model->select_all('group');
        $data['location'] = $this->super_model->select_all('location');
        
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('items/add_item_first',$data);
        $this->load->view('template/footer');
    }
    public function add_item_second(){

        $this->load->model('super_model');
        $id=$this->uri->segment(3);
        $data['item'] = $this->super_model->select_row_where("items", "item_id", $id);

        $row_sup=$this->super_model->count_rows_where("supplier_items","item_id", $id);

        if($row_sup!=0){
            foreach($this->super_model->select_row_where_order_by("supplier_items", "item_id", $id, "supplier_id", "ASC") AS $i){
                $data['supplier_item'][] = array(
                    "supplier"=> $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $i->supplier_id),
                    "catalog"=>$i->catalog_no,
                    "brand"=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $i->brand_id),
                    "item_cost"=>$i->item_cost,
                    "quantity"=>$i->quantity,
                );
            }
        } else {
             $data['supplier_item'] = array();
        }

        $data['supplier'] = $this->super_model->select_all_order_by("supplier", "supplier_name", "ASC");
        
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('items/add_item_second',$data);
        $this->load->view('template/footer');
    }

    public function insert_supplier_item(){
        $item=$this->input->post('item');
        $supplier=$this->input->post('supplier');
        $catalog=$this->input->post('catalog');
        $brandid=$this->input->post('brandid');
        $brand=$this->input->post('brand');
        $cost=$this->input->post('cost');

        $this->load->model('super_model');

        if(empty($brandid)){
           $maxid=$this->super_model->get_max("brand", "brand_id");
           $bid=$maxid+1;

           $brand_data = array(
                'brand_id' => $bid,
                'brand_name' => $brand
           );

           $this->super_model->insert_into("brand", $brand_data);

        } else {
           $bid = $brandid;
        }

        $item_data = array(
            'item_id'=> $item,
            'supplier_id'=>$supplier,
            'catalog_no'=>$catalog,
            'brand_id'=>$bid,
            'item_cost'=>$cost
        );
        if($this->super_model->insert_into("supplier_items", $item_data)){
            echo "success";
        } else {
            echo "error";
        }
       
    }

    public function update_item(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $this->load->model('super_model');
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $data['items'] = $this->super_model->select_row_where('items', 'item_id', $id);

        $catid=$this->super_model->select_column_where("items", "category_id", "item_id", $id);
        $data['cat_name'] = $this->super_model->select_column_where("item_categories", "cat_name", "cat_id", $catid);

        $binid=$this->super_model->select_column_where("items", "bin_id", "item_id", $id);
        $data['bin_name'] = $this->super_model->select_column_where("bin", "bin_name", "bin_id", $binid);

        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $data['group'] = $this->super_model->select_all('group');
        $data['location'] = $this->super_model->select_all('location');
        $this->load->view('items/update_item',$data);
        $this->load->view('template/footer');
    }

    public function edit_item(){
        $data = array(
            'category_id'=>$this->input->post('category'),
            'subcat_id'=>$this->input->post('subcat'),
            'original_pn'=>$this->input->post('pn'),
            'item_name'=>$this->input->post('item_name'),
        );
        $itemid = $this->input->post('item_id');
        $this->load->model('super_model');
            if($this->super_model->update_where('items', $data, 'item_id', $itemid)){
            echo "<script>alert('Successfully Updated'); 
                window.location ='".base_url()."index.php/items/item_list';</script>";
        }
    }

    public function view_item(){
        $data['id']=$this->uri->segment(3);
        $id=$this->uri->segment(3);
        $this->load->model('super_model');
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $data['items'] = $this->super_model->select_row_where('items', 'item_id', $id);
        $this->load->view('items/view_item',$data);
        $this->load->view('template/footer');
    }

    public function view_item_detail(){
        $this->load->model('super_model');
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('items/view_item_detail');
        $this->load->view('template/footer');
    }

    public function getcategory(){
        $subcat = $this->input->post('subcat');
        $this->load->model('super_model');
        $cat_id= $this->super_model->select_column_where('item_subcat', 'cat_id', 'subcat_id', $subcat);
        $subcat_prefix= $this->super_model->select_column_where('item_subcat', 'subcat_prefix', 'subcat_id', $subcat);
        $cat = $this->super_model->select_column_where('categories', 'category_name', 'category_id', $cat_id);

        $rows=$this->super_model->count_custom_where("pn_series","subcat_prefix = '$subcat_prefix'");
        if($rows==0){
            $pn_no= $subcat_prefix."_1001";
        } else {
            $series = $this->super_model->get_max_where("pn_series", "series","subcat_prefix = '$subcat_prefix'");
            $next=$series+1;
            $pn_no = $subcat_prefix."_".$next;
        }
        
        
        $return = array('catid' => $cat_id, 'cat' => $cat, 'pn' => $pn_no);
        echo json_encode($return);
    }

    public function search(){
        $type=$this->input->post('type');
        
        if($type=='item'){
            $item_name=$this->input->post('itemname');   
            $this->load->model('item_model');
            return $this->item_model->select_item('items', "item_name = '$item_name'");
        } else if($type=='bin'){
            $bin_name=$this->input->post('binname');   
            $this->load->model('item_model');
            return $this->item_model->select_bin('bin', "bin_name LIKE '%$bin_name%'");
        } else if($type=='brand'){
            $brand_name=$this->input->post('brandname');   
           // echo $brand_name;
            $this->load->model('item_model');
            return $this->item_model->select_brand('brand', "brand_name LIKE '%$brand_name%'");
        }
    }

    public function insert_item(){
        $itemname=$this->input->post('item_name');
        $error_ext=0;
        $dest= realpath(APPPATH . '../uploads/');
        if(!empty($_FILES['img1']['name'])){
             $img1= basename($_FILES['img1']['name']);
             $img1=explode('.',$img1);
             $ext1=$img1[1];
            
            if($ext1=='php' || ($ext1!='png' && $ext1 != 'jpg' && $ext1!='jpeg')){
                $error_ext++;
            } else {
                 $filename1=$itemname.'1.'.$ext1;
                 move_uploaded_file($_FILES["img1"]['tmp_name'], $dest.'/'.$filename1);
            }

        } else {
            $filename1="";
        }

        if(!empty($_FILES['img2']['name'])){
             $img2= basename($_FILES['img2']['name']);
             $img2=explode('.',$img2);
             $ext2=$img2[1];
             
            if($ext2=='php' || ($ext2!='png' && $ext2 != 'jpg' && $ext2!='jpeg')){
                $error_ext++;
            } else {
                $filename2=$itemname.'2.'.$ext2;
                move_uploaded_file($_FILES["img2"]['tmp_name'], $dest.'/'.$filename2);
            }
        } else {
            $filename2="";
        }

        if(!empty($_FILES['img3']['name'])){
             $img3= basename($_FILES['img3']['name']);
             $img3=explode('.',$img3);
             $ext3=$img3[1];
            
            if($ext3=='php' || ($ext3!='png' && $ext3 != 'jpg' && $ext3!='jpeg')){
                $error_ext++;
            } else {
                $filename3=$itemname.'3.'.$ext3;
                move_uploaded_file($_FILES["img3"]['tmp_name'], $dest.'/'.$filename3);
            }
        } else {
            $filename3="";
        }

        if($error_ext!=0){
            echo "ext";
        } else {
             $this->load->model('super_model');
             $binid= $this->input->post('binid');
             if(empty($binid)){
                $bin_name= $this->input->post('bin');

                
                $rows=$this->super_model->count_rows("bin");
                if($rows==0){
                    $bin = 1;
                } else {
                    $max=$this->super_model->get_max("bin", "bin_id");
                    $bin=$max+1;
                }

                $bindata = array(
                    'bin_id' => $bin,
                    'bin_name' => $bin_name
                );

                $this->super_model->insert_into("bin", $bindata);

             } else {
                $bin= $this->input->post('binid');
             }
      
            $row_items=$this->super_model->count_rows("items");
            if($row_items==0){
                $item_id=1;
            } else {
                 $maxid=$this->super_model->get_max("items", "item_id");
                 $item_id=$maxid+1;
            }

            $pndetails=explode("_", $this->input->post('pn'));
            $subcat_prefix=$pndetails[0];
            $series = $pndetails[1];

            $pn_data= array(
                'subcat_prefix'=>$subcat_prefix,
                'series'=>$series
            );
            $this->super_model->insert_into("pn_series", $pn_data);

              $data = array(
                    'item_id' => $item_id,
                    'category_id' => $this->input->post('cat'),
                    'subcat_id' => $this->input->post('subcat'),
                    'original_pn' => $this->input->post('pn'),
                    'item_name' => $this->input->post('item_name'),
                    'unit' => $this->input->post('unit'),
                    'group_id' => $this->input->post('group'),
                    'location_id' => $this->input->post('location'),
                    'bin_id' => $bin,
                    'picture1' => $filename1,
                    'picture2' => $filename2,
                    'picture3' => $filename3
             );

              if($this->super_model->insert_into("items", $data)){
                echo $item_id;
              }
        }
    }

    public function count_supplier_item(){
        $item=$this->input->post('item');
        $supplier=$this->input->post('supplier');
        $catalog=$this->input->post('catalog');
        $brand=$this->input->post('brand');

        $this->load->model('super_model');
        $row_items=$this->super_model->count_custom_where("supplier_items","item_id = '$item' AND supplier_id = '$supplier' AND catalog_no = '$catalog' AND brand_id = '$brand'");
        echo $row_items;
    }

    public function delete_item(){
        $id=$this->uri->segment(3);
        $this->load->model('super_model');
        if($this->super_model->delete_data($id)){
            echo "<script>alert('Succesfully Deleted'); 
                window.location ='".base_url()."index.php/items/item_list'; </script>";
        }
    }
}
?>