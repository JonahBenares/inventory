<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');

        date_default_timezone_set("Asia/Manila");
        $this->load->model('super_model');
        $this->dropdown['department'] = $this->super_model->select_all_order_by('department', 'department_name', 'ASC');
        $this->dropdown['purpose'] = $this->super_model->select_all_order_by('purpose', 'purpose_desc', 'ASC');
        $this->dropdown['enduse'] = $this->super_model->select_all_order_by('enduse', 'enduse_name', 'ASC');
        // $this->dropdown['prno'] = $this->super_model->select_join_where("receive_details","receive_head", "saved='1' AND create_date BETWEEN CURDATE() - INTERVAL 60 DAY AND CURDATE()","receive_id");
        //$this->dropdown['prno'] = $this->super_model->select_join_where_order("receive_details","receive_head", "saved='1'","receive_id", "receive_date", "DESC");

        
        foreach($this->super_model->select_all("receive_details") AS $dtls){
            foreach($this->super_model->select_custom_where("receive_head", "receive_id = '$dtls->receive_id'") AS $gt){
               if($gt->saved=='1'){
                    $this->dropdown['prno'][] = $dtls->pr_no;
               }
            }  
        }
        function arrayToObject($array){
            if(!is_array($array)) { return $array; }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) { $object->$name = arrayToObject($value); }
                }
                return $object;
            } else {
                return false;
            }
        }
    }

    public function itemlist(){
        $item=$this->input->post('item');
        $original_pn=$this->input->post('original_pn');
        $rows=$this->super_model->count_custom_where("items","item_name LIKE '%$item%' OR original_pn LIKE '%$original_pn%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("items", "item_name LIKE '%$item%' OR original_pn LIKE '%$item%'") AS $itm){ 
                    $name = str_replace('"', '', $itm->item_name);
                    ?>
                   <li onClick="selectItem('<?php echo $itm->item_id; ?>','<?php echo $name; ?>','<?php echo $itm->unit; ?>','<?php echo $itm->original_pn;?>')"><strong><?php echo $itm->original_pn;?> - </strong> <?php echo $name; ?></li>
                <?php 
            }
             echo "<ul>";
        }
    }

    public function supplierlist(){
        $supplier=$this->input->post('supplier');
        $rows=$this->super_model->count_custom_where("supplier","supplier_name LIKE '%$supplier%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("supplier", "supplier_name LIKE '%$supplier%'") AS $sup){ 
                    $name = str_replace('"', '', $sup->supplier_name);
                    ?>
                   <li onClick="selectSupplier('<?php echo $sup->supplier_id; ?>','<?php echo $name; ?>')"><?php echo $name; ?></li>
                <?php 
            }
             echo "<ul>";
        }
    }


    public function brandlist(){
        $brand=$this->input->post('brand');
        $rows=$this->super_model->count_custom_where("brand","brand_name LIKE '%$brand%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("brand", "brand_name LIKE '%$brand%'") AS $brnd){ 
                   
                    ?>
                   <li onClick="selectBrand('<?php echo $brnd->brand_id; ?>','<?php echo $brnd->brand_name; ?>')"><?php echo $brnd->brand_name; ?></li>
                <?php 
            }
             echo "<ul>";
        }
    }

    public function inventory_report(){
        $id=$this->uri->segment(3);
        $data['itemdesc'] = $this->super_model->select_column_where("items", "item_name", "item_id", $id);
        $total[]=array();
       // foreach($this->super_model->select_row_where_order_by('receive_items', 'item_id', $id, 'ri_id', 'DESC') AS $itms){
        //foreach($this->super_model->select_join_where_order("receive_items","receive_head", "item_id = '$id' AND saved='1'","receive_id", "receive_date", "DESC") AS $itms){
        $count=0;

        foreach($this->super_model->select_join("receive_items","receive_head", "item_id = '$id' AND saved='1'","receive_id") AS $itms){
          // echo $itms->ri_id;

            $datereceived = $this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $itms->receive_id);
            $prno = $this->super_model->select_column_where("receive_details", "pr_no", "receive_id", $itms->rd_id);
            echo $prno;
           /* $issueqty = $this->super_model->select_column_join_where("quantity","issuance_head","issuance_details", "saved='1' AND pr_no = '$prno' AND item_id='$id' AND supplier_id = '$itms->supplier_id' AND brand_id = '$itms->brand_id' AND catalog_no = '$itms->catalog_no'", "issuance_id");*/
               // $issueqty=$detls->quantity;
          
           $issueqty= $this->super_model->select_sum_join("quantity","issuance_details","issuance_head", "item_id='$id' AND supplier_id = '$itms->supplier_id' AND brand_id = '$itms->brand_id' AND catalog_no = '$itms->catalog_no' AND saved='1' AND pr_no = '$prno'","issuance_id");

          // echo $issueqty."<br>";
            //echo "**".$issueqty;
                  $balance=$itms->received_qty-$issueqty;
                  $total[]=$balance;
            //}
          
             foreach($this->super_model->select_row_where("receive_details", "rd_id", $itms->rd_id) AS $try){
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $try->enduse_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $try->purpose_id);
                $data['details'][] = array(
                    'rdid'=>$try->rd_id,
                    'prno'=>$try->pr_no,
                    'enduse'=>$enduse,
                    'purpose'=>$purpose
                );
            }
            $mifno = $this->super_model->select_column_where("issuance_head", "mif_no", "pr_no", $prno);
            $mreqfno = $this->super_model->select_column_where("issuance_head", "mreqf_no", "pr_no", $prno);
            $deptid = $this->super_model->select_column_where("issuance_head", "department_id", "pr_no", $prno);
            $department = $this->super_model->select_column_where("department", "department_name", "department_id", $deptid);
            $enduseid = $this->super_model->select_column_where("issuance_head", "enduse_id", "pr_no", $prno);
            $enduse = $this->super_model->select_column_where("enduse", "enduse_name", "enduse_id", $enduseid);
            $purposeid = $this->super_model->select_column_where("issuance_head", "purpose_id", "pr_no", $prno);
            $purpose = $this->super_model->select_column_where("purpose", "purpose_desc", "purpose_id", $purposeid);
            $mrfno = $this->super_model->select_column_where("receive_head", "mrecf_no", "receive_id", $itms->receive_id);
            $drno = $this->super_model->select_column_where("receive_head", "dr_no", "receive_id", $itms->receive_id);
            $pono = $this->super_model->select_column_where("receive_head", "po_no", "receive_id", $itms->receive_id);
            $sino = $this->super_model->select_column_where("receive_head", "si_no", "receive_id", $itms->receive_id);
            $jono = $this->super_model->select_column_where("receive_head", "jo_no", "receive_id", $itms->receive_id);
            $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $itms->supplier_id);
            $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $itms->brand_id);
            $moq = $this->super_model->select_column_where("items", "min_qty", "item_id", $itms->item_id);

            $data['items'][] = array(
                "rdid"=>$itms->rd_id,
                "date_received"=>$datereceived,
                "supplier"=>$supplier,
                "brand"=>$brand,
                "catalog_no"=>$itms->catalog_no,
                "quantity"=>$itms->received_qty,
                "mrfno"=>$mrfno,
                "drno"=>$drno,
                "pono"=>$pono,
                "sino"=>$sino,
                "jono"=>$jono,
                "exqty"=>$itms->expected_qty,
                "issueqty"=>$issueqty,
                "balance"=>$balance,
                "mifno"=>$mifno,
                "mreqfno"=>$mreqfno,
                "dept"=>$department,
                "enduse"=>$enduse,
                "purpose"=>$purpose,
                "moq"=>$moq
            );
        }
        $total_bal=array_sum($total);
        $data['totalbal']=$total_bal;
          
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/inventory_report',$data);
        $this->load->view('template/footer');
    }

     public function stock_card(){
        $id=$this->uri->segment(3);
        $sup=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $brand=$this->uri->segment(6);
        $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $sup);
                $brandname = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $brand);
        $data['itemdesc'] = $this->super_model->select_column_where("items", "item_name", "item_id", $id);
        //foreach($this->super_model->select_row_where('receive_items', 'item_id', $id) AS $it){
            $counter = $this->super_model->count_custom_where("receive_items","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'");
            //echo $id ." - ". $sup . " - " . $cat . " - " . $brand;
            if($counter!=0){
                //unset($daterec);
                
                foreach($this->super_model->select_custom_where("receive_items","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'") AS $rec){
                    $receivedate=$this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $rec->receive_id);
                    //echo $rec->receive_id;
                    $daterec[]=$receivedate;
                    $date = max($daterec);
                    $prno = $this->super_model->select_column_where("receive_details", "pr_no", "receive_id", $rec->receive_id);
                  /*  $issueqty = $this->super_model->select_column_join_where("quantity","issuance_head","issuance_details", "saved='1' AND pr_no = '$prno' AND item_id='$id' AND supplier_id = '$sup' AND brand_id = '$brand' AND catalog_no = '$cat'", "issuance_id");*/
                  //  $received_qty = $this->super_model->select_column_custom_where("receive_items","received_qty","item_id='$id' AND supplier_id = '$sup' AND brand_id = '$brand' AND catalog_no = '$cat'");
                        
                    $data['rec_itm'][] = array(
                        'supplier'=>$supplier,
                        'catalog_no'=>$cat,
                        'brand'=>$brandname,
                        'item_cost'=>$rec->item_cost,
                        'receive_qty'=>$rec->received_qty,
                        'issueqty'=>0,
                        'date'=>$date
                    );
                }
            }

            $counter_issue = $this->super_model->count_custom_where("issuance_details","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'");
            //echo $id . " - " . $sup . " - " . $cat . " - " . $brand;
             if($counter_issue!=0){
               
                foreach($this->super_model->select_custom_where("issuance_details","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'") AS $issue){
                    $issuedate=$this->super_model->select_column_where("issuance_head", "issue_date", "issuance_id", $issue->issuance_id);
                    //echo $rec->receive_id;
                    $dateiss[]=$issuedate;
                    $dateissue = max($dateiss);
                   /* $prno = $this->super_model->select_column_where("issuance_details", "pr_no", "issuance_id", $issue->issuance_id);*/
                  
                    //$issue_qty = $this->super_model->select_column_custom_where("issuance_details","quantity","item_id='$id' AND supplier_id = '$sup' AND brand_id = '$brand' AND catalog_no = '$cat'");
                        
                    $data['rec_itm'][] = array(
                        'supplier'=>$supplier,
                        'catalog_no'=>$cat,
                        'brand'=>$brandname,
                        'item_cost'=>$rec->item_cost,
                        'receive_qty'=>0,
                        'issueqty'=>$issue->quantity,
                        'date'=>$dateissue
                    );
                }
            }

       // } 
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/stock_card',$data);
        $this->load->view('template/footer');
    }

    public function generateReport(){
           $id= $this->input->post('item_id'); 
           ?>
           <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/inventory_report/<?php echo $id; ?>'</script> <?php
    } 

    public function generateStkcrd(){
        $catno=$this->input->post('catalog_no');
        $id= $this->input->post('item_id'); 
        $sid= $this->input->post('supplier_id'); 
        $bid= $this->input->post('brand_id');
        ?>

        <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/stock_card/<?php echo $id; ?>/<?php echo $sid;?>/<?php echo $catno; ?>/<?php echo $bid; ?>'
        </script> 
    <?php
    }   

    public function borrowing_report(){         
        $count=$this->super_model->select_count_join("request_items","request_head", "request_items.borrowfrom_pr !='' AND replenished='0'","request_id");
        if($count!=0){
            foreach($this->super_model->select_join_where("request_items","request_head", "request_items.borrowfrom_pr !='' AND replenished='0'","request_id") AS $itms){
               
                $data['list'][]=array(
                    'rqid'=>$itms->rq_id,
                    'mreqf_no'=>$this->super_model->select_column_where("request_head", "mreqf_no", "request_id", $itms->request_id),
                    'request_date'=>$this->super_model->select_column_where("request_head", "request_date", "request_id", $itms->request_id),
                    'request_time'=>$this->super_model->select_column_where("request_head", "request_time", "request_id", $itms->request_id),
                    'original_pr'=>$this->super_model->select_column_where("request_head", "pr_no", "request_id", $itms->request_id),
                    'borrowfrom'=>$itms->borrowfrom_pr,
                    'quantity'=>$itms->quantity,
                    'supplier'=>$this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $itms->supplier_id),
                    'item'=>$this->super_model->select_column_where("items", "item_name", "item_id", $itms->item_id),
                    'brand'=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $itms->brand_id),
                    'catalog'=>$itms->catalog_no


                );
            } 
        } else {
            $data['list']=array();
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/borrowing_report',$data);
        $this->load->view('template/footer');
    }

    public function replenishborrow(){
        $id=$this->input->post('id');

        $data=array(
            'replenished'=>'1'
        );

        if($this->super_model->update_where("request_items", $data, "rq_id", $id)){
            echo "ok";
        }
    }

}
?>
