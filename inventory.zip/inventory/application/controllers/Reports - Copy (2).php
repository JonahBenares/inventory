<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');

        date_default_timezone_set("Asia/Manila");
        $this->load->model('super_model');
        $this->dropdown['department'] = $this->super_model->select_all_order_by('department', 'department_name', 'ASC');
        $this->dropdown['purpose'] = $this->super_model->select_all_order_by('purpose', 'purpose_desc', 'ASC');
        $this->dropdown['enduse'] = $this->super_model->select_all_order_by('enduse', 'enduse_name', 'ASC');
        // $this->dropdown['prno'] = $this->super_model->select_join_where("receive_details","receive_head", "saved='1' AND create_date BETWEEN CURDATE() - INTERVAL 60 DAY AND CURDATE()","receive_id");
        //$this->dropdown['prno'] = $this->super_model->select_join_where_order("receive_details","receive_head", "saved='1'","receive_id", "receive_date", "DESC");
         if(isset($_SESSION['user_id'])){
        $sessionid= $_SESSION['user_id'];
      
        foreach($this->super_model->get_table_columns("access_rights") AS $col){
            $this->access[$col]=$this->super_model->select_column_where("access_rights",$col, "user_id", $sessionid);
            $this->dropdown[$col]=$this->super_model->select_column_where("access_rights",$col, "user_id", $sessionid);
            
        }
      }
        
       foreach($this->super_model->select_custom_where_group("receive_details", "closed=0", "pr_no") AS $dtls){
            foreach($this->super_model->select_custom_where("receive_head", "receive_id = '$dtls->receive_id'") AS $gt){
               if($gt->saved=='1'){
                    $this->dropdown['prno'][] = $dtls->pr_no;
               }
            }  
        }
        function arrayToObject($array){
            if(!is_array($array)) { return $array; }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) { $object->$name = arrayToObject($value); }
                }
                return $object;
            } else {
                return false;
            }
        }
    }

    public function itemlist(){
        $item=$this->input->post('item');
        $original_pn=$this->input->post('original_pn');
        $rows=$this->super_model->count_custom_where("items","item_name LIKE '%$item%' OR original_pn LIKE '%$original_pn%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("items", "item_name LIKE '%$item%' OR original_pn LIKE '%$item%'") AS $itm){ 
                    $name = str_replace('"', '', $itm->item_name);
                    ?>
                   <li onClick="selectItem('<?php echo $itm->item_id; ?>','<?php echo $name; ?>','<?php echo $itm->unit_id; ?>','<?php echo $itm->original_pn;?>')"><strong><?php echo $itm->original_pn;?> - </strong> <?php echo $name; ?></li>
                <?php 
            }
             echo "<ul>";
        }
    }

    public function supplierlist(){
        $supplier=$this->input->post('supplier');
        $rows=$this->super_model->count_custom_where("supplier","supplier_name LIKE '%$supplier%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("supplier", "supplier_name LIKE '%$supplier%'") AS $sup){ 
                    $name = str_replace('"', '', $sup->supplier_name);
                    ?>
                   <li onClick="selectSupplier('<?php echo $sup->supplier_id; ?>','<?php echo $name; ?>')"><?php echo $name; ?></li>
                <?php 
            }
             echo "<ul>";
        }
    }


    public function prlist(){
        $pr=$this->input->post('pr');
        $rows=$this->super_model->count_custom_where("receive_details","pr_no LIKE '%$pr%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("receive_details", "pr_no LIKE '%$pr%'") AS $pr){ 
                    ?>
                    <?php if($pr->closed == '0'){ ?>
                    <li onClick="selectPr('<?php echo $pr->receive_id; ?>','<?php echo $pr->pr_no; ?>')"><?php echo $pr->pr_no; ?> <span class="fa fa-unlock"></span></li>
                    <?php } else { ?>
                    <li onClick="selectPr('<?php echo $pr->receive_id; ?>','<?php echo $pr->pr_no; ?>')"><?php echo $pr->pr_no; ?> <span class="fa fa-lock"></span></li>
                    <?php } ?>
                <?php 
            }
             echo "<ul>";
        }
    }

    public function brandlist(){
        $brand=$this->input->post('brand');
        $rows=$this->super_model->count_custom_where("brand","brand_name LIKE '%$brand%'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("brand", "brand_name LIKE '%$brand%'") AS $brnd){ 
                   
                    ?>
                   <li onClick="selectBrand('<?php echo $brnd->brand_id; ?>','<?php echo $brnd->brand_name; ?>')"><?php echo $brnd->brand_name; ?></li>
                <?php 
            }
             echo "<ul>";
        }
    }

    public function qty_received($item,$supplier,$brand,$catalog){
        $qty=$this->super_model->select_sum_where("supplier_items","quantity","item_id='$item' AND supplier_id = '$supplier' AND brand_id = '$brand' AND catalog_no = '$catalog'");
        return $qty;
    }

    public function qty_issued($item,$supplier,$brand,$catalog){
        $qty=$this->super_model->select_sum_where("issuance_details","quantity","item_id='$item' AND supplier_id = '$supplier' AND brand_id = '$brand' AND catalog_no = '$catalog'");
        return $qty;
    }

    public function dateDifference($date_1 , $date_2){
        $datetime2 = date_create($date_2);
        $datetime1 = date_create($date_1 );
        $interval = date_diff($datetime2, $datetime1);
        return $interval->format('%R%a');
    }

    public function aging_report(){
        $this->load->view('template/header');
        $this->load->view('template/topbar');
        $days=$this->uri->segment(3);
        $data['days']=$days;
        if(empty($days)){
            

            foreach($this->super_model->custom_query("SELECT DISTINCT item_id, supplier_id, brand_id, catalog_no FROM receive_items") as $items){
                $data['item_info'][] = array(
                    'item'=>$items->item_id,
                    'supplier'=>$items->supplier_id,
                    'brand'=>$items->brand_id,
                    'catalog_no'=>$items->catalog_no,
                    'item_desc'=>$this->super_model->select_column_where('items', 'item_name', 'item_id', $items->item_id),
                    'supplier_name'=>$this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $items->supplier_id),
                    'brand_name'=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $items->brand_id),
                );
            }

            foreach($this->super_model->custom_query("SELECT DISTINCT item_id, supplier_id, brand_id, catalog_no FROM receive_items") as $items){
                $item[] = array(
                    'item'=>$items->item_id,
                    'supplier'=>$items->supplier_id,
                    'brand'=>$items->brand_id,
                    'catalog_no'=>$items->catalog_no
                );
            }

           foreach($item AS $i){
                foreach($this->super_model->custom_query("SELECT DISTINCT receive_id FROM receive_items WHERE item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]'") AS $q){
                    $unit_cost = $this->super_model->select_column_custom_where("receive_items", "item_cost", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                    $qty = $this->super_model->select_sum_where("receive_items", "received_qty", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                    $unit_x = $qty * $unit_cost;
                    $receive_date = $this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $q->receive_id);
                   
                    $data['info'][]=array(
                        'receive_id'=>$q->receive_id,
                        'receive_date'=>$receive_date,
                        'unit_cost'=>$unit_cost,
                        'qty'=>$qty,
                        'unit_x'=>$unit_x,
                        'item'=>$i['item'],
                        'supplier'=>$i['supplier'],
                        'brand'=>$i['brand'],
                        'catalog_no'=>$i['catalog_no']
                    );
                }
            /*foreach($this->super_model->select_all('receive_head') as $head){
                    
                    foreach ($this->super_model->custom_query("SELECT DISTINCT item_id,supplier_id,brand_id,catalog_no,received_qty,receive_id FROM receive_items WHERE receive_id = '$head->receive_id'") as $age) {
                        $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $age->item_id);
                        $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $age->supplier_id);
                        $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $age->brand_id);
                        $data['date'] = $head->receive_date;
                        $receive_date = $head->receive_date;

                        $data['aging'][] = array(
                            "item"=>$item,
                            "date"=>$receive_date,
                            "qty"=>$age->received_qty,
                            "supplier"=>$supplier,
                            "brand"=>$brand,
                            "catalog_no"=>$age->catalog_no,
                            "sub"=>$new
                        );
                    }
                }*/

            }
        } else {
            $startdate = date('Y-m-d',strtotime("-".$days." days"));
            $now=date('Y-m-d');
            foreach($this->super_model->custom_query("SELECT receive_id,receive_date FROM receive_head WHERE receive_date BETWEEN '$startdate' AND '$now'") as $head){

                    foreach($this->super_model->custom_query("SELECT DISTINCT item_id, supplier_id, brand_id, catalog_no FROM receive_items WHERE receive_id = '$head->receive_id'") as $items){
                        $item[] = array(
                            'item'=>$items->item_id,
                            'supplier'=>$items->supplier_id,
                            'brand'=>$items->brand_id,
                            'catalog_no'=>$items->catalog_no
                        );
                    }
                    foreach($item AS $i){
                        foreach($this->super_model->custom_query("SELECT DISTINCT receive_id FROM receive_items WHERE item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$head->receive_id'") AS $q){
                            $unit_cost = $this->super_model->select_column_custom_where("receive_items", "item_cost", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                            $qty = $this->super_model->select_sum_where("receive_items", "received_qty", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                            $unit_x = $qty * $unit_cost;
                            $receive_date = $this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $q->receive_id);
                            $data['info'][]=array(
                                'receive_id'=>$q->receive_id,
                                'receive_date'=>$receive_date,
                                'unit_cost'=>$unit_cost,
                                'qty'=>$qty,
                                'unit_x'=>$unit_x,
                                'item'=>$this->super_model->select_column_where('items', 'item_name', 'item_id', $i['item']),
                                'supplier'=>$this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $i['supplier']),
                                'brand'=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $i['brand']),
                                'catalog_no'=>$i['catalog_no']
                            );
                        }
                    /*foreach ($this->super_model->custom_query("SELECT DISTINCT item_id,supplier_id,brand_id,catalog_no,received_qty,receive_id FROM receive_items WHERE receive_id = '$head->receive_id'") as $age) {
                        $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $age->item_id);
                        $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $age->supplier_id);
                        $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $age->brand_id);
                          $data['aging'][] = array(
                            "item"=>$item,
                             "date"=>$head->receive_date,
                            "qty"=>$age->received_qty,
                            "supplier"=>$supplier,
                            "brand"=>$brand,
                            "catalog_no"=>$age->catalog_no,
                            "sub"=>$new
                        );
                    }*/
                } 
            } 
                       
        }
        $this->load->view('reports/aging_report',$data);
        $this->load->view('template/footer');
    }

    public function aging_report2(){
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);

        foreach($this->super_model->custom_query("SELECT DISTINCT item_id, supplier_id, brand_id, catalog_no FROM receive_items") as $items){
            $item[] = array(
                'item'=>$items->item_id,
                'supplier'=>$items->supplier_id,
                'brand'=>$items->brand_id,
                'catalog_no'=>$items->catalog_no
            );
        }

       /* foreach($this->super_model->custom_query("SELECT DISTINCT item_id, supplier_id, brand_id, catalog_no FROM receive_items") as $items){
            $data['item_info'][] = array(
                'item'=>$items->item_id,
                'supplier'=>$items->supplier_id,
                'brand'=>$items->brand_id,
                'catalog_no'=>$items->catalog_no,
                'item_desc'=>$this->super_model->select_column_where('items', 'item_name', 'item_id', $items['item']),
                'supplier_name'=>$this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $items['supplier']),
                'brand_name'=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $items['brand']),
            );
        }*/

       foreach($item AS $i){
            foreach($this->super_model->custom_query("SELECT DISTINCT receive_id FROM receive_items WHERE item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]'") AS $q){
            $unit_cost = $this->super_model->select_column_custom_where("receive_items", "item_cost", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
            $qty = $this->super_model->select_sum_where("receive_items", "received_qty", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
            $count = $this->super_model->count_custom_where("receive_items", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
            $unit_x = $qty * $unit_cost;

            $receive_date = $this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $q->receive_id);
            $data['info'][]=array(
                'receive_id'=>$q->receive_id,
                'receive_date'=>$receive_date,
                'unit_cost'=>$unit_cost,
                'count'=>$count,
                'qty'=>$qty,
                'unit_x'=>$unit_x,
                'item'=>$this->super_model->select_column_where('items', 'item_name', 'item_id', $i['item']),
                'supplier'=>$this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $i['supplier']),
                'brand'=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $i['brand']),
                'catalog_no'=>$i['catalog_no']
            );
            }
       }
        $this->load->view('reports/aging_report2',$data);
        $this->load->view('template/footer');
    }

    public function inventory_report(){
        $id=$this->uri->segment(3);
        $data['itemdesc'] = $this->super_model->select_column_where("items", "item_name", "item_id", $id);
        $total=array();
        foreach($this->super_model->select_row_where_group4("supplier_items", "item_id", $id, "item_id", "supplier_id", "brand_id", "catalog_no") AS $it){
             $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $it->supplier_id);
            $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $it->brand_id);
            $recqty=$this->qty_received($id,$it->supplier_id, $it->brand_id,$it->catalog_no);
            $issqty=$this->qty_issued($id,$it->supplier_id, $it->brand_id,$it->catalog_no);
            $balance=$recqty-$issqty;
            $total[]=$balance;
            $data['items'][]=array(
                "supplier"=>$supplier,
                "brand"=>$brand,
                "catalog"=>$it->catalog_no,
                "received_qty"=>$recqty,
                "issued_qty"=>$issqty,
                "balance"=>$balance
            );
        }


        $totalbal=array_sum($total);
        $data['totalbal']=$totalbal;
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/inventory_report',$data);
        $this->load->view('template/footer');
        
    }



    public function pr_report(){
        $id=$this->uri->segment(3);
        $prno=$this->uri->segment(4);
        $counter = $this->super_model->count_custom_where("receive_head","receive_id = '$id'");
        if($counter!=0){
            foreach($this->super_model->select_row_where("receive_head", "receive_id",$id) AS $head){
                $data['head'][]=array(
                    "recid"=>$head->receive_id,
                    "drno"=>$head->dr_no,
                    "jono"=>$head->jo_no,
                    "pono"=>$head->po_no,
                    "sino"=>$head->si_no,
                    "pcf"=>$head->pcf,
                    "recdate"=>$head->receive_date
                );
            } 
        }else {
            $data['head'] = array();
        }
        foreach($this->super_model->select_custom_where("receive_details", "receive_id = '$id' AND pr_no = '$prno'") AS $det){
                $department = $this->super_model->select_column_where("department", "department_name", "department_id", $det->department_id);
                $enduse = $this->super_model->select_column_where("enduse", "enduse_name", "enduse_id", $det->enduse_id);
                $purpose = $this->super_model->select_column_where("purpose", "purpose_desc", "purpose_id", $det->purpose_id);
                $data['details'][]=array(
                    "recid"=>$det->receive_id,
                    "prno"=>$det->pr_no,
                    "department"=>$department,
                    "enduse"=>$enduse,
                    "purpose"=>$purpose,
                    "closed"=>$det->closed
                );
            foreach($this->super_model->select_custom_where("receive_items", "rd_id = '$det->rd_id'") AS $itm){
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $item){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $item->unit_id);
                }
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                /*$unit = $this->super_model->select_column_where('items', 'unit', 'item_id', $itm->item_id);*/
                $brand = $this->super_model->select_column_where('brand', 'brand_name', 'brand_id', $itm->brand_id);
                $inspected = $this->super_model->select_column_where('employees', 'employee_name', 'employee_id', $itm->inspected_by);
                $serial = $this->super_model->select_column_where('serial_number', 'serial_no', 'serial_id', $itm->serial_id);
                $data['items'][] = array(
                    'supplier'=>$supplier,
                    'recid'=>$itm->receive_id,
                    'item'=>$item,
                    'brand'=>$brand,
                    'unit_cost'=>$itm->item_cost,
                    'catalog_no'=>$itm->catalog_no,
                    'serial'=>$serial,
                    'unit'=>$unit,
                    'expqty'=>$itm->expected_qty,
                    'recqty'=>$itm->received_qty,
                    'inspected'=>$inspected,
                    'remarks'=>$itm->remarks
                );
            }
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/pr_report',$data);
        $this->load->view('template/footer');
    }

    public function getCat(){
        $cat = $this->input->post('category');
        $sub= $this->super_model->select_column_where('item_subcat', 'cat_id', 'cat_id', $cat);
        $subcat= $this->super_model->select_column_where('item_subcat', 'subcat_name', 'cat_id', $sub);
        $return = array('sub' => $sub, 'subcat' => $subcat);
        echo json_encode($return);
    }


    public function inventory_balance($itemid){
         $recqty= $this->super_model->select_sum("supplier_items", "quantity", "item_id", $itemid);
      //   $issueqty= $this->super_model->select_sum_join("quantity","issuance_details","issuance_head", "item_id='$itemid' AND saved='1'","issuance_id");
         $issueqty= $this->super_model->select_sum("issuance_details","quantity", "item_id",$itemid);
         $balance=$recqty-$issueqty;
         return $balance;
    }

    public function range_date(){
        $from=$this->uri->segment(3);
        $to=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $subcat=$this->uri->segment(6);
        $data['from']=$this->uri->segment(3);
        $data['to']=$this->uri->segment(4);
        $data['catt']=$this->uri->segment(5);
        $data['subcat1']=$this->uri->segment(6);
        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $data['category'] = $this->super_model->select_all('item_categories');
        $data['c'] = $this->super_model->select_column_where("item_categories", "cat_name", "cat_id", $cat);
        $data['s'] = $this->super_model->select_column_where("item_subcat", "subcat_name", "subcat_id", $subcat);
        $sql="";
        if($from!='null' && $to!='null'){
           $sql.= " rh.receive_date BETWEEN '$from' AND '$to' AND";
        }

        if($cat!='null'){
            $sql.= " i.category_id = '$cat' AND";
        }

        if($subcat!='null'){
            $sql.= " i.subcat_id = '$subcat' AND";
        }

        $query=substr($sql,0,-3);
        $count=$this->super_model->custom_query("SELECT rh.* FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id WHERE rh.saved='1' AND ".$query);
        if($count!=0){
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id  FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id WHERE rh.saved='1' AND ".$query) AS $head){
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $head->item_id);
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $head->item_id);
                $totalqty=$this->inventory_balance($head->item_id);
                $data['head'][] = array(
                    'item'=>$item,
                    'pn'=>$pn,
                    'total'=>$totalqty
                );          
            }
        } 
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/range_date',$data);
        $this->load->view('template/footer');
    }

    public function received_report(){
        $from=$this->uri->segment(3);
        $to=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $subcat=$this->uri->segment(6);
        $data['from']=$this->uri->segment(3);
        $data['to']=$this->uri->segment(4);
        $data['catt1']=$this->uri->segment(5);
        $data['subcat2']=$this->uri->segment(6);
        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $data['category'] = $this->super_model->select_all('item_categories');
        $data['c'] = $this->super_model->select_column_where("item_categories", "cat_name", "cat_id", $cat);
        $data['s'] = $this->super_model->select_column_where("item_subcat", "subcat_name", "subcat_id", $subcat);
        $sql="";
        if($from!='null' && $to!='null'){
           $sql.= " rh.receive_date BETWEEN '$from' AND '$to' AND";
        }

        if($cat!='null'){
            $sql.= " i.category_id = '$cat' AND";
        }

        if($subcat!='null'){
            $sql.= " i.subcat_id = '$subcat' AND";
        }

        $query=substr($sql,0,-3);
        $count=$this->super_model->custom_query("SELECT rh.* FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id INNER JOIN receive_details rd ON rd.receive_id = ri.receive_id WHERE rh.saved='1' AND ".$query);
        if($count!=0){
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, ri.ri_id FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN receive_details rd ON rd.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = ri.supplier_id INNER JOIN department dt ON dt.department_id = rd.department_id INNER JOIN purpose pr ON pr.purpose_id = rd.purpose_id INNER JOIN enduse e ON e.enduse_id = rd.enduse_id WHERE rh.saved='1' AND ri.rd_id = rd.rd_id AND ".$query."ORDER BY rh.receive_date DESC") AS $itm){
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $recqty = $this->super_model->select_column_where('receive_items', 'received_qty', 'ri_id', $itm->ri_id); 
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                $pr = $this->super_model->select_column_where('receive_details', 'pr_no', 'receive_id', $itm->receive_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);  
                $rec_date = $this->super_model->select_column_where('receive_head', 'receive_date', 'receive_id', $itm->receive_id);
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $itema){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
                }             
                $data['rec'][] = array( 
                    'pr'=>$pr, 
                    'unit'=>$unit,
                    'rec_date'=>$rec_date,       
                    'supplier'=>$supplier,
                    'item'=>$item,
                    'department'=>$department,
                    'purpose'=>$purpose,
                    'enduse'=>$enduse,
                    'pn'=>$pn,
                    'recqty'=>$recqty,
                );
            }
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/received_report',$data);
        $this->load->view('template/footer');
    }

    public function issued_report(){
        $from=$this->uri->segment(3);
        $to=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $subcat=$this->uri->segment(6);
        $data['from']=$this->uri->segment(3);
        $data['to']=$this->uri->segment(4);
        $data['catt']=$this->uri->segment(5);
        $data['subcat1']=$this->uri->segment(6);
        $data['subcat'] = $this->super_model->select_all('item_subcat');
        $data['category'] = $this->super_model->select_all('item_categories');
        $data['c'] = $this->super_model->select_column_where("item_categories", "cat_name", "cat_id", $cat);
        $data['s'] = $this->super_model->select_column_where("item_subcat", "subcat_name", "subcat_id", $subcat);
        $sql="";
        if($from!='null' && $to!='null'){
           $sql.= " ih.issue_date BETWEEN '$from' AND '$to' AND";
        }

        if($cat!='null'){
            $sql.= " i.category_id = '$cat' AND";
        }

        if($subcat!='null'){
            $sql.= " i.subcat_id = '$subcat' AND";
        }

        $query=substr($sql,0,-3);
        $count=$this->super_model->custom_query("SELECT ih.* FROM issuance_head ih INNER JOIN issuance_details id ON ih.issuance_id = id.issuance_id INNER JOIN items i ON id.item_id = i.item_id WHERE ih.saved='1' AND ".$query);
        if($count!=0){
            foreach($this->super_model->custom_query("SELECT ih.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, id.is_id FROM issuance_head ih INNER JOIN issuance_details id ON ih.issuance_id = id.issuance_id INNER JOIN items i ON id.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = id.supplier_id INNER JOIN department dt ON dt.department_id = ih.department_id INNER JOIN purpose pr ON pr.purpose_id = ih.purpose_id INNER JOIN enduse e ON e.enduse_id = ih.enduse_id WHERE ih.saved='1' AND ih.issuance_id = id.issuance_id AND ".$query. "ORDER BY ih.issue_date") AS $itm){
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $issqty = $this->super_model->select_column_where('issuance_details', 'quantity', 'is_id', $itm->is_id); 
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                $issue_date = $this->super_model->select_column_where('issuance_head', 'issue_date', 'issuance_id', $itm->issuance_id);
                $pr = $this->super_model->select_column_where('receive_details', 'pr_no', 'receive_id', $itm->issuance_id);
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $itema){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
                }
                $data['issue'][] = array(
                    'issue_date'=>$issue_date,
                    'pr'=>$pr,
                    'unit'=>$unit,
                    'supplier'=>$supplier,
                    'item'=>$item,
                    'department'=>$department,
                    'purpose'=>$purpose,
                    'enduse'=>$enduse,
                    'pn'=>$pn,
                    'issqty'=>$issqty,
                );
            }
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/issued_report',$data);
        $this->load->view('template/footer');
    }

    public function stock_card(){
        $id=$this->uri->segment(3);
        $sup=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $brand=$this->uri->segment(6);
        $arr_rec=array();
        $arr_iss=array();
        $arr_rs=array();
        $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $sup);
                $brandname = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $brand);
        $data['itemdesc'] = $this->super_model->select_column_where("items", "item_name", "item_id", $id);
        //foreach($this->super_model->select_row_where('receive_items', 'item_id', $id) AS $it){
            $counter = $this->super_model->count_custom_where("receive_items","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'");
            //echo $id ." - ". $sup . " - " . $cat . " - " . $brand;
            if($counter!=0){
                //unset($daterec);
                
                foreach($this->super_model->select_custom_where("receive_items","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'") AS $rec){
                    $receivedate=$this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $rec->receive_id);
                    //echo $rec->receive_id;
                    $daterec[]=$receivedate;
                    $date = max($daterec);
                    $prno = $this->super_model->select_column_where("receive_details", "pr_no", "receive_id", $rec->receive_id);
                  /*  $issueqty = $this->super_model->select_column_join_where("quantity","issuance_head","issuance_details", "saved='1' AND pr_no = '$prno' AND item_id='$id' AND supplier_id = '$sup' AND brand_id = '$brand' AND catalog_no = '$cat'", "issuance_id");*/
                  //  $received_qty = $this->super_model->select_column_custom_where("receive_items","received_qty","item_id='$id' AND supplier_id = '$sup' AND brand_id = '$brand' AND catalog_no = '$cat'");
                    $arr_rec[]=$rec->received_qty;
                    $data['rec_itm'][] = array(
                        'supplier'=>$supplier,
                        'catalog_no'=>$cat,
                        'brand'=>$brandname,
                        'item_cost'=>$rec->item_cost,
                        'receive_qty'=>$rec->received_qty,
                        'issueqty'=>0,
                        'restockqty'=>0,
                        'date'=>$date
                    );
                }
            }

            $counter_issue = $this->super_model->count_custom_where("issuance_details","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'");
            //echo $id . " - " . $sup . " - " . $cat . " - " . $brand;
             if($counter_issue!=0){
               
                foreach($this->super_model->select_custom_where("issuance_details","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'") AS $issue){
                    $issuedate=$this->super_model->select_column_where("issuance_head", "issue_date", "issuance_id", $issue->issuance_id);
                    //echo $rec->receive_id;
                    $dateiss[]=$issuedate;
                    $dateissue = max($dateiss);
                   /* $prno = $this->super_model->select_column_where("issuance_details", "pr_no", "issuance_id", $issue->issuance_id);*/
                  
                    //$issue_qty = $this->super_model->select_column_custom_where("issuance_details","quantity","item_id='$id' AND supplier_id = '$sup' AND brand_id = '$brand' AND catalog_no = '$cat'");
                    $arr_iss[]=$issue->quantity;
                    $data['rec_itm'][] = array(
                        'supplier'=>$supplier,
                        'catalog_no'=>$cat,
                        'brand'=>$brandname,
                        'item_cost'=>$rec->item_cost,
                        'receive_qty'=>0,
                        'issueqty'=>$issue->quantity,
                        'restockqty'=>0,
                        'date'=>$dateissue
                    );
                }
            }

             $counter_restock = $this->super_model->count_custom_where("restock","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'");
            //echo $id . " - " . $sup . " - " . $cat . " - " . $brand;
             if($counter_restock!=0){
               
                foreach($this->super_model->select_custom_where("restock","item_id = '$id' AND supplier_id = '$sup' AND catalog_no = '$cat' AND brand_id = '$brand'") AS $restock){
                    $restockdate=$this->super_model->select_column_where("restock", "restock_date", "restock_id", $restock->restock_id);
                    //echo $rec->receive_id;
                    $datest[]=$restockdate;
                    $datestock = max($datest);
                   /* $prno = $this->super_model->select_column_where("issuance_details", "pr_no", "issuance_id", $issue->issuance_id);*/
                  
                    //$issue_qty = $this->super_model->select_column_custom_where("issuance_details","quantity","item_id='$id' AND supplier_id = '$sup' AND brand_id = '$brand' AND catalog_no = '$cat'");
                    $arr_rs[]=$restock->quantity;
                    $data['rec_itm'][] = array(
                        'supplier'=>$supplier,
                        'catalog_no'=>$cat,
                        'brand'=>$brandname,
                        'item_cost'=>$rec->item_cost,
                        'receive_qty'=>0,
                        'issueqty'=>0,
                        'restockqty'=>$restock->quantity,
                        'date'=>$datestock
                    );
                }
            }

            $sumrec=array_sum($arr_rec);
            $sumiss=array_sum($arr_iss);
            $sumst=array_sum($arr_rs);
            $total=($sumrec+$sumst)-$sumiss;
            $data['total']=$total;
       // } 
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/stock_card',$data);
        $this->load->view('template/footer');
    }

    public function generateReport(){
           $id= $this->input->post('item_id'); 
           ?>
           <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/inventory_report/<?php echo $id; ?>'</script> <?php
    } 

    public function generateRange(){

           if(!empty($this->input->post('from'))){
                $from = $this->input->post('from');
           } else {
                $from = "null";
           }

           if(!empty($this->input->post('to'))){
                $to = $this->input->post('to');
           } else {
                $to = "null";
           }

           if(!empty($this->input->post('category'))){
                $cat = $this->input->post('category');
           } else {
                $cat = "null";
           }

           if(!empty($this->input->post('subcat'))){
                $subcat = $this->input->post('subcat');
           } else {
                $subcat = "null";
           }


      
           ?>
           <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/range_date/<?php echo $from; ?>/<?php echo $to; ?>/<?php echo $cat; ?>/<?php echo $subcat; ?>'</script> <?php
    }

    public function generateReceived(){
           if(!empty($this->input->post('from'))){
                $from = $this->input->post('from');
           } else {
                $from = "null";
           }

           if(!empty($this->input->post('to'))){
                $to = $this->input->post('to');
           } else {
                $to = "null";
           }

           if(!empty($this->input->post('category'))){
                $cat = $this->input->post('category');
           } else {
                $cat = "null";
           }

           if(!empty($this->input->post('subcat'))){
                $subcat = $this->input->post('subcat');
           } else {
                $subcat = "null";
           } 
           ?>
           <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/received_report/<?php echo $from; ?>/<?php echo $to; ?>/<?php echo $cat; ?>/<?php echo $subcat; ?>'</script> <?php
    }

    public function generateIssue(){
           if(!empty($this->input->post('from'))){
                $from = $this->input->post('from');
           } else {
                $from = "null";
           }

           if(!empty($this->input->post('to'))){
                $to = $this->input->post('to');
           } else {
                $to = "null";
           }

           if(!empty($this->input->post('category'))){
                $cat = $this->input->post('category');
           } else {
                $cat = "null";
           }

           if(!empty($this->input->post('subcat'))){
                $subcat = $this->input->post('subcat');
           } else {
                $subcat = "null";
           } 
           ?>
           <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/issued_report/<?php echo $from; ?>/<?php echo $to; ?>/<?php echo $cat; ?>/<?php echo $subcat; ?>'</script> <?php
    }

    public function generateItemReport(){
           $id= $this->input->post('item_id'); 
           ?>
           <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/item_report/<?php echo $id; ?>'</script> <?php
    } 


    public function generateStkcrd(){
        $catno=$this->input->post('catalog_no');
        $id= $this->input->post('item_id'); 
        $sid= $this->input->post('supplier_id'); 
        $bid= $this->input->post('brand_id');
        ?>

        <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/stock_card/<?php echo $id; ?>/<?php echo $sid;?>/<?php echo $catno; ?>/<?php echo $bid; ?>'
        </script> 
    <?php
    } 
    public function generatePr(){
        $prno=$this->input->post('pr');
        $prid=$this->input->post('prid');
        ?>
        <script>
            window.location.href ='<?php echo base_url(); ?>index.php/reports/pr_report/<?php echo $prid;?>/<?php echo $prno;?>'
        </script> 
    <?php
    }  

    public function borrowing_report(){         
        $count=$this->super_model->select_count_join_inner("request_items","issuance_head", "request_items.borrowfrom_pr !='' AND replenished='0'","request_id");
        if($count!=0){
            foreach($this->super_model->select_join_where_inner("request_items","issuance_head", "request_items.borrowfrom_pr !='' AND replenished='0'","request_id") AS $itms){
               
                $data['list'][]=array(
                    'rqid'=>$itms->rq_id,
                    'mreqf_no'=>$this->super_model->select_column_where("request_head", "mreqf_no", "request_id", $itms->request_id),
                    'request_date'=>$this->super_model->select_column_where("request_head", "request_date", "request_id", $itms->request_id),
                    'request_time'=>$this->super_model->select_column_where("request_head", "request_time", "request_id", $itms->request_id),
                    'original_pr'=>$this->super_model->select_column_where("request_head", "pr_no", "request_id", $itms->request_id),
                    'borrowfrom'=>$itms->borrowfrom_pr,
                    'quantity'=>$itms->quantity,
                    'supplier'=>$this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $itms->supplier_id),
                    'item'=>$this->super_model->select_column_where("items", "item_name", "item_id", $itms->item_id),
                    'brand'=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $itms->brand_id),
                    'catalog'=>$itms->catalog_no


                );
            } 
        } else {
            $data['list']=array();
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/borrowing_report',$data);
        $this->load->view('template/footer');
    }

    public function replenishborrow(){
        $id=$this->input->post('id');

        $data=array(
            'replenished'=>'1'
        );

        if($this->super_model->update_where("request_items", $data, "rq_id", $id)){
            echo "ok";
        }
    }

    public function item_report(){
        $id=$this->uri->segment(3);
        $data['itemdesc']=$this->super_model->select_column_where("items", "item_name", "item_id", $id);

        foreach($this->super_model->custom_query("SELECT pr_no, SUM(received_qty) AS qty FROM receive_items ri INNER JOIN receive_details rd ON ri.rd_id = rd.rd_id WHERE ri.item_id = '$id' GROUP BY rd.pr_no") AS $head){
            /*$issueqty=$this->super_model->custom_query_single("qty","SELECT SUM(quantity) AS qty FROM issuance_head ih INNER JOIN issuance_details id WHERE item_id= '$id' AND pr_no='$head->pr_no' GROUP BY pr_no");*/
          //  $qty=$this->super_model->select_sum_join_group("received_qty","receive_items","receive_details", "receive_details.receive_id = '$head->receive_id'", "rd_id","pr_no");
                $issueqty= $this->super_model->select_sum_join("quantity","issuance_details","issuance_head", "item_id='$id' AND pr_no='$head->pr_no'","issuance_id");
                $total=$head->qty-$issueqty;
                $data['list'][] = array(
                    "prno"=>$head->pr_no,
                    "recqty"=>$head->qty,
                    "issueqty"=>$issueqty,
                    "total"=>$total
                );
            
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('reports/item_report',$data);
        $this->load->view('template/footer');
    }

    public function export(){
        $from=$this->uri->segment(3);
        $to=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $subcat=$this->uri->segment(6);
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $exportfilename="Inventory Report.xlsx";

        $gdImage = imagecreatefrompng('assets/default/logo_cenpri.png');
        // Add a drawing to the worksheetecho date('H:i:s') . " Add a drawing to the worksheet\n";
        $objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
        $objDrawing->setName('Sample image');
        $objDrawing->setDescription('Sample image');
        $objDrawing->setImageResource($gdImage);
        $objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
        $objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
        $objDrawing->setHeight(35);
        $objDrawing->setCoordinates('A2');
        $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save(str_replace('.php', '.xlsx', __FILE__));

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A5', "Date");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A7', "Warehouse");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A8', "Main Category");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A10', "No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B10', "Item Part No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E10', "Item Description");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K10', "Avail. Qty");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', "CENTRAL NEGROS POWER RELIABILITY, INC.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C2', "Purok San Jose, Brgy. Calumangan, Bago City");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', "Tel. No. 476 - 7382");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H1', "MATERIAL INVENTORY REPORT");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I2', "TO DATE");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F8', "Sub-Category");
        $num=11;
        foreach($this->super_model->select_custom_where("receive_head","receive_date BETWEEN '$from' AND '$to'") AS $head){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C5', $from.' - '.$to);
        } 
         foreach($this->super_model->select_custom_where("item_categories","cat_id = '$cat'") AS $category){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C8', $category->cat_name);
            /*$num++;*/
        }
        foreach($this->super_model->select_custom_where("item_subcat","subcat_id = '$subcat'") AS $sub){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H8', $sub->subcat_name);
            /*$num++;*/
        }
        $x = 1;
        if($from != 'null' && $to != 'null' && $cat != 'null' && $subcat != 'null'){ 
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id  FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id WHERE rh.saved='1' AND i.category_id = '$cat' AND i.subcat_id = '$subcat' AND rh.receive_date BETWEEN '$from' AND '$to'") AS $head){
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $head->item_id);
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $head->item_id);
                $totalqty=$this->inventory_balance($head->item_id);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$num, $item);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $totalqty);
                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":H".$num,'admin');
                $x++;
                $num++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":D".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('E'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->getStyle('H'.$num.":K".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }
        else if($from != 'null' && $to != 'null'){
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id  FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id WHERE rh.receive_date BETWEEN '$from' AND '$to' AND rh.saved='1'") AS $head){
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $head->item_id);
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $head->item_id);
                $totalqty=$this->inventory_balance($head->item_id);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$num, $item);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K'.$num, $totalqty);
                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":L".$num,'admin');
                $x++;
                $num++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":D".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('E'.$num.":J".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('K'.$num.":L".$num);
                $objPHPExcel->getActiveSheet()->getStyle('K'.$num.":L".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            } 
        }else if($subcat != 'null' && $cat != 'null'){
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id  FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id WHERE rh.saved='1' AND i.category_id = '$cat' AND i.subcat_id = '$subcat'") AS $head){
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $head->item_id);
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $head->item_id);
                $totalqty=$this->inventory_balance($head->item_id);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$num, $item);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $totalqty);
                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":H".$num,'admin');
                $x++;
                $num++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":D".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('E'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->getStyle('H'.$num.":K".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }else {
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id  FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id WHERE rh.saved='1'") AS $head){
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $head->item_id);
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $head->item_id);
                $totalqty=$this->inventory_balance($head->item_id);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$num, $item);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $totalqty);
                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":H".$num,'admin');
                $x++;
                $num++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":D".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('E'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->getStyle('H'.$num.":K".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }
         $styleArray = array(
          'borders' => array(
            'allborders' => array(
              'style' => PHPExcel_Style_Border::BORDER_THIN
            )
          )
        );
        $num--;
        $objPHPExcel->getActiveSheet()->mergeCells('B10:D10');
        $objPHPExcel->getActiveSheet()->mergeCells('E10:J10');
        $objPHPExcel->getActiveSheet()->mergeCells('K10:L10');
        $objPHPExcel->getActiveSheet()->mergeCells('B11:D11');
        $objPHPExcel->getActiveSheet()->mergeCells('E11:J11');
        $objPHPExcel->getActiveSheet()->mergeCells('K11:L11');
        $objPHPExcel->getActiveSheet()->mergeCells('H1:L1');
        $objPHPExcel->getActiveSheet()->mergeCells('I2:K2');
        /*$objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":D".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('E'.$num.":G".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);*/
        $objPHPExcel->getActiveSheet()->getStyle('A10:L10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('K11:L11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        /*$objPHPExcel->getActiveSheet()->getStyle('H'.$num.":K".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);*/
        $objPHPExcel->getActiveSheet()->getStyle('A10:L'.$num)->applyFromArray($styleArray);
        $objPHPExcel->getActiveSheet()->getStyle('A3:L3')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C5:E5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H8:J8')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C8:E8')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('L1')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('L2')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('L3')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFont()->setBold(true);
        /*$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);*/
        $objPHPExcel->getActiveSheet()->getStyle('H2')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle("H1")->getFont()->setBold(true)->setName('Arial Black')->setSize(10);
        $objPHPExcel->getActiveSheet()->getStyle("I2")->getFont()->setBold(true)->setName('Arial Black')->setSize(10);
        $objPHPExcel->getActiveSheet()->getStyle('H1:L1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('I2:K2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        /*$objPHPExcel->getActiveSheet()->getStyle('I2')->getFont()->setBold(true);*/
        //$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if (file_exists($exportfilename))
        unlink($exportfilename);
        $objWriter->save($exportfilename);
        unset($objPHPExcel);
        unset($objWriter);   
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Inventory Report.xlsx"');
        readfile($exportfilename);
        //echo "<script>window.location = 'import_items';</script>";
    }

    public function export_rec(){
        $from=$this->uri->segment(3);
        $to=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $subcat=$this->uri->segment(6);
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $exportfilename="Received Report.xlsx";

        $gdImage = imagecreatefrompng('assets/default/logo_cenpri.png');
        // Add a drawing to the worksheetecho date('H:i:s') . " Add a drawing to the worksheet\n";
        $objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
        $objDrawing->setName('Sample image');
        $objDrawing->setDescription('Sample image');
        $objDrawing->setImageResource($gdImage);
        $objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
        $objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
        $objDrawing->setHeight(35);
        $objDrawing->setCoordinates('A2');
        $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save(str_replace('.php', '.xlsx', __FILE__));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A5', "Period Covered:");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A7', "Warehouse");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A8', "Main Category");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A10', "No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B10', "Received Date");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D10', "PR No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F10', "Item Part No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H10', "Item Description");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L10', "UoM");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M10', "Total Qty Received");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O10', "Supplier");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R10', "Department");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('U10', "Purpose");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X10', "End Use");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', "CENTRAL NEGROS POWER RELIABILITY, INC.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C2', "Purok San Jose, Brgy. Calumangan, Bago City");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', "Tel. No. 476 - 7382");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C5', "TO");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G5', "FROM");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N2', "SUMMARY OF RECIEVED MATERIALS");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F8', "Sub-Category");
        $num=11;
        foreach($this->super_model->select_custom_where("receive_head","receive_date BETWEEN '$from' AND '$to'") AS $head){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D5', $from);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H5', $to);
        } 
         foreach($this->super_model->select_custom_where("item_categories","cat_id = '$cat'") AS $category){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C8', $category->cat_name);
            /*$num++;*/
        }
        foreach($this->super_model->select_custom_where("item_subcat","subcat_id = '$subcat'") AS $sub){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H8', $sub->subcat_name);
            /*$num++;*/
        }
        $x = 1;
        if($cat != 'null' && $subcat != 'null' && $from != 'null' && $to != 'null'){
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, ri.ri_id FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN receive_details rd ON rd.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = ri.supplier_id INNER JOIN department dt ON dt.department_id = rd.department_id INNER JOIN purpose pr ON pr.purpose_id = rd.purpose_id INNER JOIN enduse e ON e.enduse_id = rd.enduse_id WHERE rh.saved='1' AND i.category_id = '$cat' AND i.subcat_id = '$subcat' AND rh.receive_date BETWEEN '$from' AND '$to' AND ri.rd_id = rd.rd_id ") AS $itm){
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $recqty = $this->super_model->select_column_where('receive_items', 'received_qty', 'ri_id', $itm->ri_id); 
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                $recdate = $this->super_model->select_column_where('receive_head', 'receive_date', 'receive_id', $itm->receive_id); 
                $pr = $this->super_model->select_column_where('receive_details', 'pr_no', 'receive_id', $itm->receive_id);
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $itema){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
                }
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $recdate);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $pr);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $item); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $unit); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M'.$num, $recqty); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O'.$num, $supplier); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $department); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('U'.$num, $purpose);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X'.$num, $enduse);

                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":Z".$num,'admin');

                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('M11:N11');
                $objPHPExcel->getActiveSheet()->mergeCells('M'.$num.":N".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('O11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('O'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R11:T11');
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('U11:W11');
                $objPHPExcel->getActiveSheet()->mergeCells('U'.$num.":W".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('X11:Z11');
                $objPHPExcel->getActiveSheet()->mergeCells('X'.$num.":Z".$num);
                $objPHPExcel->getActiveSheet()->getStyle('L11:N11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objPHPExcel->getActiveSheet()->getStyle('L'.$num.":M".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }  
        }
        else if($from != 'null' && $to != 'null'){
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, ri.ri_id FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN receive_details rd ON rd.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = ri.supplier_id INNER JOIN department dt ON dt.department_id = rd.department_id INNER JOIN purpose pr ON pr.purpose_id = rd.purpose_id INNER JOIN enduse e ON e.enduse_id = rd.enduse_id WHERE rh.receive_date BETWEEN '$from' AND '$to' AND rh.saved='1' AND ri.rd_id = rd.rd_id ") AS $itm){
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $recqty = $this->super_model->select_column_where('receive_items', 'received_qty', 'ri_id', $itm->ri_id); 
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                $recdate = $this->super_model->select_column_where('receive_head', 'receive_date', 'receive_id', $itm->receive_id); 
                $pr = $this->super_model->select_column_where('receive_details', 'pr_no', 'receive_id', $itm->receive_id);
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $itema){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
                }
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $recdate);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $pr);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $item); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $unit); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M'.$num, $recqty); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O'.$num, $supplier); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $department); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('U'.$num, $purpose);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X'.$num, $enduse);

                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":Z".$num,'admin');

                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('M11:N11');
                $objPHPExcel->getActiveSheet()->mergeCells('M'.$num.":N".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('O11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('O'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R11:T11');
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('U11:W11');
                $objPHPExcel->getActiveSheet()->mergeCells('U'.$num.":W".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('X11:Z11');
                $objPHPExcel->getActiveSheet()->mergeCells('X'.$num.":Z".$num);
                $objPHPExcel->getActiveSheet()->getStyle('L11:N11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objPHPExcel->getActiveSheet()->getStyle('L'.$num.":M".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }
        else if($subcat != 'null' && $cat != 'null'){
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, ri.ri_id FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN receive_details rd ON rd.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = ri.supplier_id INNER JOIN department dt ON dt.department_id = rd.department_id INNER JOIN purpose pr ON pr.purpose_id = rd.purpose_id INNER JOIN enduse e ON e.enduse_id = rd.enduse_id WHERE rh.saved='1' AND i.category_id = '$cat' AND i.subcat_id = '$subcat' AND ri.rd_id = rd.rd_id") AS $itm){
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $recqty = $this->super_model->select_column_where('receive_items', 'received_qty', 'ri_id', $itm->ri_id); 
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                $recdate = $this->super_model->select_column_where('receive_head', 'receive_date', 'receive_id', $itm->receive_id); 
                $pr = $this->super_model->select_column_where('receive_details', 'pr_no', 'receive_id', $itm->receive_id);
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $itema){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
                }
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $recdate);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $pr);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $item); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $unit); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M'.$num, $recqty); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O'.$num, $supplier); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $department); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('U'.$num, $purpose);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X'.$num, $enduse);

                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":Z".$num,'admin');

                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('M11:N11');
                $objPHPExcel->getActiveSheet()->mergeCells('M'.$num.":N".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('O11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('O'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R11:T11');
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('U11:W11');
                $objPHPExcel->getActiveSheet()->mergeCells('U'.$num.":W".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('X11:Z11');
                $objPHPExcel->getActiveSheet()->mergeCells('X'.$num.":Z".$num);
                $objPHPExcel->getActiveSheet()->getStyle('L11:N11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objPHPExcel->getActiveSheet()->getStyle('L'.$num.":M".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }
        else {
            foreach($this->super_model->custom_query("SELECT rh.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, ri.ri_id FROM receive_head rh INNER JOIN receive_items ri ON rh.receive_id = ri.receive_id INNER JOIN receive_details rd ON rd.receive_id = ri.receive_id INNER JOIN items i ON ri.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = ri.supplier_id INNER JOIN department dt ON dt.department_id = rd.department_id INNER JOIN purpose pr ON pr.purpose_id = rd.purpose_id INNER JOIN enduse e ON e.enduse_id = rd.enduse_id WHERE rh.saved='1'") AS $itm){
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $recqty = $this->super_model->select_column_where('receive_items', 'received_qty', 'ri_id', $itm->ri_id); 
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                $recdate = $this->super_model->select_column_where('receive_head', 'receive_date', 'receive_id', $itm->receive_id); 
                $pr = $this->super_model->select_column_where('receive_details', 'pr_no', 'receive_id', $itm->receive_id);
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $itema){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
                }
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $recdate);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $pr);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $item); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $unit); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M'.$num, $recqty); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O'.$num, $supplier); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $department); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('U'.$num, $purpose);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X'.$num, $enduse);

                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":Z".$num,'admin');

                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('M11:N11');
                $objPHPExcel->getActiveSheet()->mergeCells('M'.$num.":N".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('O11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('O'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R11:T11');
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('U11:W11');
                $objPHPExcel->getActiveSheet()->mergeCells('U'.$num.":W".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('X11:Z11');
                $objPHPExcel->getActiveSheet()->mergeCells('X'.$num.":Z".$num);
                $objPHPExcel->getActiveSheet()->getStyle('L11:N11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objPHPExcel->getActiveSheet()->getStyle('L'.$num.":M".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }
         $styleArray = array(
          'borders' => array(
            'allborders' => array(
              'style' => PHPExcel_Style_Border::BORDER_THIN
            )
          )
        );
        $num--;
        /*$objPHPExcel->getActiveSheet()->mergeCells('H1:K1');*/
        $objPHPExcel->getActiveSheet()->mergeCells('N2:T2');
        $objPHPExcel->getActiveSheet()->mergeCells('B10:C10');
        $objPHPExcel->getActiveSheet()->mergeCells('D10:E10');
        $objPHPExcel->getActiveSheet()->mergeCells('F10:G10');
        $objPHPExcel->getActiveSheet()->mergeCells('H10:K10');
        $objPHPExcel->getActiveSheet()->mergeCells('M10:N10');
        $objPHPExcel->getActiveSheet()->mergeCells('O10:Q10');
        $objPHPExcel->getActiveSheet()->mergeCells('R10:T10');
        $objPHPExcel->getActiveSheet()->mergeCells('U10:W10');
        $objPHPExcel->getActiveSheet()->mergeCells('X10:Z10');
        $objPHPExcel->getActiveSheet()->mergeCells('B11:C11');
        /*$objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
        $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
        $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('H11:I11');
        $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":I".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('J11:K11');
        $objPHPExcel->getActiveSheet()->mergeCells('J'.$num.":K".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('L11:M11');
        $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('N11:O11');
        $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);*/
        $objPHPExcel->getActiveSheet()->getStyle('A10:Z10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
       /* $objPHPExcel->getActiveSheet()->getStyle('F11:G11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);*/
        /*$objPHPExcel->getActiveSheet()->getStyle('F'.$num.":G11".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);*/
        $objPHPExcel->getActiveSheet()->getStyle('A10:Z'.$num)->applyFromArray($styleArray);
        $objPHPExcel->getActiveSheet()->getStyle('A3:Z3')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A1:Z1')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A1:Z1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A2:Z2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A3:Z3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A1:Z1')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A2:Z2')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A3:Z3')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('D5:E5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H5:I5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H8:J8')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C8:E8')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('Z1')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('Z2')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('Z3')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('C5')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('G5')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('H2')->getFont()->setBold(true);
       /* $objPHPExcel->getActiveSheet()->getStyle('J2')->getFont()->setBold(true);*/
        $objPHPExcel->getActiveSheet()->getStyle("N2")->getFont()->setBold(true)->setName('Arial Black');
        $objPHPExcel->getActiveSheet()->getStyle('N2:T2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        //$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
       /* $objPHPExcel->getActiveSheet()->getSecurity()->setLockWindows(true);
        $objPHPExcel->getActiveSheet()->getSecurity()->setLockStructure(true);*/
        /*$objPHPExcel->getActiveSheet()
            ->getStyle('A1:F1')
            ->getProtection()->setLocked(
                PHPExcel_Style_Protection::PROTECTION_UNPROTECTED
            );*/
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if (file_exists($exportfilename))
        unlink($exportfilename);
        $objWriter->save($exportfilename);
        unset($objPHPExcel);
        unset($objWriter);   
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Received Report.xlsx"');
        readfile($exportfilename);
        //echo "<script>window.location = 'import_items';</script>";
    }

    public function export_issue(){
        $from=$this->uri->segment(3);
        $to=$this->uri->segment(4);
        $cat=$this->uri->segment(5);
        $subcat=$this->uri->segment(6);
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $exportfilename="Issued Report.xlsx";


        $gdImage = imagecreatefrompng('assets/default/logo_cenpri.png');
        // Add a drawing to the worksheetecho date('H:i:s') . " Add a drawing to the worksheet\n";
        $objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
        $objDrawing->setName('Sample image');
        $objDrawing->setDescription('Sample image');
        $objDrawing->setImageResource($gdImage);
        $objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
        $objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
        $objDrawing->setHeight(35);
        $objDrawing->setCoordinates('A2');
        $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save(str_replace('.php', '.xlsx', __FILE__));
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A5', "Period Covered:");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A7', "Warehouse");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A8', "Main Category");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A10', "No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B10', "Issue Date");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D10', "PR No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F10', "Item Part No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H10', "Item Description");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L10', "UoM");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M10', "Total Qty Received");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O10', "Supplier");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R10', "Department");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('U10', "Purpose");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X10', "End Use");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('AA10', "Frequency");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', "CENTRAL NEGROS POWER RELIABILITY, INC.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C2', "Purok San Jose, Brgy. Calumangan, Bago City");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C3', "Tel. No. 476 - 7382");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C5', "TO");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G5', "FROM");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O2', "SUMMARY OF ISSUED MATERIALS");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F8', "Sub-Category");
        $num=11;
        foreach($this->super_model->select_custom_where("receive_head","receive_date BETWEEN '$from' AND '$to'") AS $head){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D5', $from);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H5', $to);
        } 
         foreach($this->super_model->select_custom_where("item_categories","cat_id = '$cat'") AS $category){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C8', $category->cat_name);
            /*$num++;*/
        }
        foreach($this->super_model->select_custom_where("item_subcat","subcat_id = '$subcat'") AS $sub){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H8', $sub->subcat_name);
            /*$num++;*/
        }
        $x = 1;
        if($cat != 'null' && $subcat != 'null' && $from != 'null' && $to != 'null'){
            foreach($this->super_model->custom_query("SELECT ih.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, id.is_id FROM issuance_head ih INNER JOIN issuance_details id ON ih.issuance_id = id.issuance_id INNER JOIN items i ON id.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = id.supplier_id INNER JOIN department dt ON dt.department_id = ih.department_id INNER JOIN purpose pr ON pr.purpose_id = ih.purpose_id INNER JOIN enduse e ON e.enduse_id = ih.enduse_id WHERE ih.saved='1' AND i.category_id = '$cat' AND i.subcat_id = '$subcat' AND ih.issue_date BETWEEN '$from' AND '$to' AND ih.issuance_id = id.issuance_id") AS $itm){
                    $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                    $issqty = $this->super_model->select_column_where('issuance_details', 'quantity', 'is_id', $itm->is_id); 
                    $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                    $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                    $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                    $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                    $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $pn);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $item); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $issqty); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $supplier); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J'.$num, $department); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $purpose);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$num, $enduse);
                        $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                        $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":N".$num,'admin');
                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:I11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":I".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('J11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('J'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('L11:M11');
                $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('N11:O11');
                $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('P11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->getStyle('F'.$num.":G11".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }else if($from != 'null' && $to != 'null'){
            foreach($this->super_model->custom_query("SELECT ih.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, id.is_id FROM issuance_head ih INNER JOIN issuance_details id ON ih.issuance_id = id.issuance_id INNER JOIN items i ON id.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = id.supplier_id INNER JOIN department dt ON dt.department_id = ih.department_id INNER JOIN purpose pr ON pr.purpose_id = ih.purpose_id INNER JOIN enduse e ON e.enduse_id = ih.enduse_id WHERE ih.issue_date BETWEEN '$from' AND '$to' AND ih.saved='1' AND ih.issuance_id = id.issuance_id") AS $itm){
                $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                $issqty = $this->super_model->select_column_where('issuance_details', 'quantity', 'is_id', $itm->is_id); 
                $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                $pr = $this->super_model->select_column_where('issuance_head', 'pr_no', 'issuance_id', $itm->issuance_id);
                foreach($this->super_model->select_custom_where("items", "item_id = '$itm->item_id'") AS $itema){
                    $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
                }
                $issdate = $this->super_model->select_column_where('issuance_head', 'issue_date', 'issuance_id', $itm->issuance_id);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $issdate);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $pr);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $pn);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $item); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $unit); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M'.$num, $issqty); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('O'.$num, $supplier); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $department); 
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('U'.$num, $purpose);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X'.$num, $enduse);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('AA'.$num, '');
                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":AA".$num,'admin');
                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('M11:N11');
                $objPHPExcel->getActiveSheet()->mergeCells('M'.$num.":N".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('O11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('O'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R11:T11');
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":T".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('U11:W11');
                $objPHPExcel->getActiveSheet()->mergeCells('U'.$num.":W".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('X11:Z11');
                $objPHPExcel->getActiveSheet()->mergeCells('X'.$num.":Z".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('AA11:AB11');
                $objPHPExcel->getActiveSheet()->mergeCells('AA'.$num.":AB".$num);
                $objPHPExcel->getActiveSheet()->getStyle('L'.$num.":N".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }
        else if($subcat != 'null' && $cat != 'null'){
            foreach($this->super_model->custom_query("SELECT ih.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, id.is_id FROM issuance_head ih INNER JOIN issuance_details id ON ih.issuance_id = id.issuance_id INNER JOIN items i ON id.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = id.supplier_id INNER JOIN department dt ON dt.department_id = ih.department_id INNER JOIN purpose pr ON pr.purpose_id = ih.purpose_id INNER JOIN enduse e ON e.enduse_id = ih.enduse_id WHERE ih.issue_date BETWEEN '$from' AND '$to' AND ih.saved='1' AND i.category_id = '$cat' AND i.subcat_id = '$subcat' AND ih.issuance_id = id.issuance_id") AS $itm){
                    $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                    $issqty = $this->super_model->select_column_where('issuance_details', 'quantity', 'is_id', $itm->is_id); 
                    $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                    $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                    $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                    $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                    $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $pn);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $item); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $issqty); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $supplier); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J'.$num, $department); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $purpose);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$num, $enduse);
                        $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                        $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":N".$num,'admin');
                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:I11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":I".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('J11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('J'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('L11:M11');
                $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('N11:O11');
                $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('P11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->getStyle('F'.$num.":G11".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        }
        else {
            foreach($this->super_model->custom_query("SELECT ih.*,i.item_id, sr.supplier_id,dt.department_id,pr.purpose_id,e.enduse_id, id.is_id FROM issuance_head ih INNER JOIN issuance_details id ON ih.issuance_id = id.issuance_id INNER JOIN items i ON id.item_id = i.item_id INNER JOIN supplier sr ON sr.supplier_id = id.supplier_id INNER JOIN department dt ON dt.department_id = ih.department_id INNER JOIN purpose pr ON pr.purpose_id = ih.purpose_id INNER JOIN enduse e ON e.enduse_id = ih.enduse_id WHERE ih.issue_date BETWEEN '$from' AND '$to' AND ih.saved='1' AND ih.issuance_id = id.issuance_id") AS $itm){
                    $supplier = $this->super_model->select_column_where('supplier', 'supplier_name', 'supplier_id', $itm->supplier_id);
                    $issqty = $this->super_model->select_column_where('issuance_details', 'quantity', 'is_id', $itm->is_id); 
                    $pn = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $itm->item_id);
                    $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $itm->item_id);
                    $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $itm->department_id);
                    $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $itm->purpose_id);
                    $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $itm->enduse_id);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $x);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num, $pn);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num, $item); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $issqty); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $supplier); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J'.$num, $department); 
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $purpose);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$num, $enduse);
                        $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);    
                        $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":N".$num,'admin');
                $num++;
                $x++;
                $objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
                $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H11:I11');
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":I".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('J11:K11');
                $objPHPExcel->getActiveSheet()->mergeCells('J'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('L11:M11');
                $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('N11:O11');
                $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('P11:Q11');
                $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->getStyle('F'.$num.":G11".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }
        } 
         $styleArray = array(
          'borders' => array(
            'allborders' => array(
              'style' => PHPExcel_Style_Border::BORDER_THIN
            )
          )
        );
        $num--;
        $objPHPExcel->getActiveSheet()->mergeCells('O2:T2');
        $objPHPExcel->getActiveSheet()->mergeCells('B10:C10');
        $objPHPExcel->getActiveSheet()->mergeCells('D10:E10');
        $objPHPExcel->getActiveSheet()->mergeCells('F10:G10');
        $objPHPExcel->getActiveSheet()->mergeCells('H10:K10');
        $objPHPExcel->getActiveSheet()->mergeCells('M10:N10');
        $objPHPExcel->getActiveSheet()->mergeCells('O10:Q10');
        $objPHPExcel->getActiveSheet()->mergeCells('R10:T10');
        $objPHPExcel->getActiveSheet()->mergeCells('U10:W10');
        $objPHPExcel->getActiveSheet()->mergeCells('X10:Z10');
        $objPHPExcel->getActiveSheet()->mergeCells('AA10:AB10');
        $objPHPExcel->getActiveSheet()->mergeCells('B11:C11');
        /*$objPHPExcel->getActiveSheet()->mergeCells('B'.$num.":C".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('D11:E11');
        $objPHPExcel->getActiveSheet()->mergeCells('D'.$num.":E".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('F11:G11');
        $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('H11:I11');
        $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":I".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('J11:K11');
        $objPHPExcel->getActiveSheet()->mergeCells('J'.$num.":K".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('L11:M11');
        $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('N11:O11');
        $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
        $objPHPExcel->getActiveSheet()->mergeCells('P11:Q11');
        $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);*/
        $objPHPExcel->getActiveSheet()->getStyle('A10:AA10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('L11:N11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
         $objPHPExcel->getActiveSheet()->getStyle('A10:AB'.$num)->applyFromArray($styleArray);
        /*$objPHPExcel->getActiveSheet()->getStyle('F'.$num.":G11".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);*/
        $objPHPExcel->getActiveSheet()->getStyle('A10:AB'.$num)->applyFromArray($styleArray);
        $objPHPExcel->getActiveSheet()->getStyle('A3:AB3')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A1:AB1')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A1:AB1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A2:AB2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('A3:AB3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('D5:E5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H5:I5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H8:J8')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C8:E8')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('C3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H2')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('H3')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('AB1')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('AB2')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('AB3')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('O2:T2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('C5')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('G5')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('H2')->getFont()->setBold(true);
       /* $objPHPExcel->getActiveSheet()->getStyle('J2')->getFont()->setBold(true);*/
        $objPHPExcel->getActiveSheet()->getStyle("O2")->getFont()->setBold(true)->setName('Arial Black');
        //$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if (file_exists($exportfilename))
        unlink($exportfilename);
        $objWriter->save($exportfilename);
        unset($objPHPExcel);
        unset($objWriter);   
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Issued Report.xlsx"');
        readfile($exportfilename);
        //echo "<script>window.location = 'import_items';</script>";
    }

    public function export_aging(){
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $exportfilename="Aging.xlsx";
       
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', "Item Description");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F1', "Brand");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H1', "Supplier");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L1', "Catalog No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N1', "Quantity");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P1', "Unit Cost");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R1', "1-30");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('T1', "31-60");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('V1', "61-90");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X1', "91-120");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('Z1', "120+");
        $num=2;
        /*foreach($this->super_model->select_all('receive_head') as $head){
            foreach ($this->super_model->custom_query("SELECT DISTINCT item_id,supplier_id,brand_id,catalog_no,received_qty,receive_id FROM receive_items WHERE receive_id = '$head->receive_id' ORDER BY receive_id DESC") as $age) {
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $age->item_id);
                $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $age->supplier_id);
                $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $age->brand_id);
                $receive_date = $head->receive_date;
                $cat_no = $age->catalog_no;
                $qty = $age->received_qty;*/
            foreach($this->super_model->custom_query("SELECT DISTINCT item_id, supplier_id, brand_id, catalog_no FROM receive_items") as $items){
                $item[] = array(
                    'item'=>$items->item_id,
                    'supplier'=>$items->supplier_id,
                    'brand'=>$items->brand_id,
                    'catalog_no'=>$items->catalog_no
                );
            }

           foreach($item AS $i){
                foreach($this->super_model->custom_query("SELECT DISTINCT receive_id FROM receive_items WHERE item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]'") AS $q){
                $unit_cost = $this->super_model->select_column_custom_where("receive_items", "item_cost", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                $qty = $this->super_model->select_sum_where("receive_items", "received_qty", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                $unit_x = $qty * $unit_cost;
                $receive_date = $this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $q->receive_id);
                $now = date("Y-m-d");
                $diff = $this->dateDifference($now,$receive_date);
                $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $i['supplier']);
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $i['item']);
                $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $i['brand']);
                $cat_no = $i['catalog_no'];
                /*$unx = number_format($unit_x,2);*/

                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $item);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $brand);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $supplier);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $cat_no);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$num, $qty);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P'.$num, $unit_cost);
                $objPHPExcel->getActiveSheet()->getStyle('P'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                if($diff > 1 && $diff<30){
                   $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $unit_x);
                   $objPHPExcel->getActiveSheet()->getStyle('R'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                }else {
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, '');
                }

                if($diff >= 31 && $diff<=60){
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('T'.$num, $unit_x);
                    $objPHPExcel->getActiveSheet()->getStyle('T'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                }else {
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('T'.$num, '');
                }

                if($diff >= 61 && $diff <=90){
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('V'.$num, $unit_x);
                    $objPHPExcel->getActiveSheet()->getStyle('V'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                }else {
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('V'.$num, '');
                }

                if($diff >= 91 && $diff<=120){
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X'.$num, $unit_x);
                    $objPHPExcel->getActiveSheet()->getStyle('X'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                }else {
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('X'.$num, ''); 
                }

                if($diff>120){
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('Z'.$num, $unit_x);
                    $objPHPExcel->getActiveSheet()->getStyle('Z'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                }else {
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('Z'.$num, '');
                }

                $objPHPExcel->getActiveSheet()->mergeCells('A'.$num.":E".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":S".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('T'.$num.":U".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('V'.$num.":W".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('X'.$num.":Y".$num);
                $objPHPExcel->getActiveSheet()->mergeCells('Z'.$num.":AA".$num);
                $objPHPExcel->getActiveSheet()->getStyle('N'.$num.":AA".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);
                $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":AA".$num,'admin');
                $num++;
            }
        }
        $objPHPExcel->getActiveSheet()->mergeCells('A1:E1');
        $objPHPExcel->getActiveSheet()->mergeCells('F1:G1');
        $objPHPExcel->getActiveSheet()->mergeCells('H1:K1');
        $objPHPExcel->getActiveSheet()->mergeCells('L1:M1');
        $objPHPExcel->getActiveSheet()->mergeCells('N1:O1');
        $objPHPExcel->getActiveSheet()->mergeCells('P1:Q1');
        $objPHPExcel->getActiveSheet()->mergeCells('R1:S1');
        $objPHPExcel->getActiveSheet()->mergeCells('T1:U1');
        $objPHPExcel->getActiveSheet()->mergeCells('V1:W1');
        $objPHPExcel->getActiveSheet()->mergeCells('X1:Y1');
        $objPHPExcel->getActiveSheet()->mergeCells('Z1:AA1');
        $objPHPExcel->getActiveSheet()->getStyle('N1:AA1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A1:AA1')->getFont()->setBold(true);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if (file_exists($exportfilename))
        unlink($exportfilename);
        $objWriter->save($exportfilename);
        unset($objPHPExcel);
        unset($objWriter);   
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Aging.xlsx"');
        readfile($exportfilename);
    }

    public function export_aging_range(){
        $days=$this->uri->segment(3);
        $data['days']=$days;
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $exportfilename="Aging Range.xlsx";
       
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', "Item Description");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F1', "Brand");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H1', "Supplier");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L1', "Catalog No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N1', "Quantity");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P1', "Unit Cost");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R1', "Total Cost");
        $num=2;
            /*$startdate = date('Y-m-d',strtotime("-".$days." days"));
            $now=date('Y-m-d');
            foreach($this->super_model->custom_query("SELECT receive_id,receive_date FROM receive_head WHERE receive_date BETWEEN '$startdate' AND '$now'") as $head){
                    foreach ($this->super_model->custom_query("SELECT DISTINCT item_id,supplier_id,brand_id,catalog_no,received_qty,receive_id FROM receive_items WHERE receive_id = '$head->receive_id'") as $age) {
                $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $age->item_id);
                $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $age->supplier_id);
                $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $age->brand_id);
                $receive_date = $head->receive_date;
                $cat_no = $age->catalog_no;
                $qty = $age->received_qty;*/
                $startdate = date('Y-m-d',strtotime("-".$days." days"));
                $now=date('Y-m-d');
                foreach($this->super_model->custom_query("SELECT receive_id,receive_date FROM receive_head WHERE receive_date BETWEEN '$startdate' AND '$now'") as $head){

                        foreach($this->super_model->custom_query("SELECT DISTINCT item_id, supplier_id, brand_id, catalog_no FROM receive_items WHERE receive_id = '$head->receive_id'") as $items){
                            $itemss [] = array(
                                'item'=>$items->item_id,
                                'supplier'=>$items->supplier_id,
                                'brand'=>$items->brand_id,
                                'catalog_no'=>$items->catalog_no
                            );
                        }
                        foreach($itemss AS $i){
                            foreach($this->super_model->custom_query("SELECT DISTINCT receive_id FROM receive_items WHERE item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$head->receive_id'") AS $q){
                            $unit_cost = $this->super_model->select_column_custom_where("receive_items", "item_cost", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                            $qty = $this->super_model->select_sum_where("receive_items", "received_qty", "item_id = '$i[item]' AND supplier_id = '$i[supplier]' AND brand_id = '$i[brand]' AND catalog_no = '$i[catalog_no]' AND receive_id = '$q->receive_id'");
                            $unit_x = $qty * $unit_cost;
                            $receive_date = $this->super_model->select_column_where("receive_head", "receive_date", "receive_id", $q->receive_id);
                            $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $i['supplier']);
                            $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $i['item']);
                            $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $i['brand']);
                            $cat_no = $i['catalog_no'];
                        $diff = $this->dateDifference($now,$receive_date);
                        $start_diff=$days-29;
                    if($days!='121'){
                        if($diff>= $start_diff && $diff <= $days) {
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $item);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $brand);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $supplier);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $cat_no);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$num, $qty);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P'.$num, $unit_cost);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $unit_x);

                            $objPHPExcel->getActiveSheet()->getStyle('N'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                            $objPHPExcel->getActiveSheet()->getStyle('P'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                            $objPHPExcel->getActiveSheet()->getStyle('R'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                            $objPHPExcel->getActiveSheet()->mergeCells('A'.$num.":E".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":S".$num);
                            $objPHPExcel->getActiveSheet()->getStyle('N'.$num.":S".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                            $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);
                            $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":S".$num,'admin');
                            $num++;
                        }
                    }else {
                        if($diff>= $days) {
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num, $item);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num, $brand);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num, $supplier);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num, $cat_no);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$num, $qty);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('P'.$num, $unit_cost);
                            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('R'.$num, $unit_x);
                            $objPHPExcel->getActiveSheet()->getStyle('N'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                            $objPHPExcel->getActiveSheet()->getStyle('P'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                            $objPHPExcel->getActiveSheet()->getStyle('R'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
                            $objPHPExcel->getActiveSheet()->mergeCells('A'.$num.":E".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);
                            $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":S".$num);
                            $objPHPExcel->getActiveSheet()->getStyle('N'.$num.":S".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                            $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);
                            $objPHPExcel->getActiveSheet()->protectCells('A'.$num.":S".$num,'admin');
                            $num++;
                        }
                    }
                }
            }
        }
        $objPHPExcel->getActiveSheet()->mergeCells('A1:E1');
        $objPHPExcel->getActiveSheet()->mergeCells('F1:G1');
        $objPHPExcel->getActiveSheet()->mergeCells('H1:K1');
        $objPHPExcel->getActiveSheet()->mergeCells('L1:M1');
        $objPHPExcel->getActiveSheet()->mergeCells('N1:O1');
        $objPHPExcel->getActiveSheet()->mergeCells('P1:Q1');
        $objPHPExcel->getActiveSheet()->mergeCells('R1:S1');
        $objPHPExcel->getActiveSheet()->getStyle('A1:S1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A1:S1')->getFont()->setBold(true);
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if (file_exists($exportfilename))
        unlink($exportfilename);
        $objWriter->save($exportfilename);
        unset($objPHPExcel);
        unset($objWriter);   
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Aging Range.xlsx"');
        readfile($exportfilename);
    }

    public function export_all_rec(){
        $days=$this->uri->segment(3);
        $data['days']=$days;
        require_once(APPPATH.'../assets/js/phpexcel/Classes/PHPExcel/IOFactory.php');
        $objPHPExcel = new PHPExcel();
        $exportfilename="All Receive.xlsx";
       
        $objPHPExcel = new PHPExcel();
       /* $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A11', "Item No");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B11', "UoM");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C11', "Part No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D11', "Item Description");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E11', "Expected Qty.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F11', "Receive Qty.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G11', "Supplier");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H11', "Catalog No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I11', "Brand");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J11', "Serial No.");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K11', "Unit Cost");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L11', "Total Cost");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M11', "Inspected By");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N11', "Remarks");*/
        $num=12;
        $num1=1;
        $num2=2;
        $num3=3;
        $num4=4;
        $num5=5;
        $num6=6;
        $num7=7;
        $num8=8;
        $num9=9;
        $x = 1;
            $startdate = "2018-09-12";
            $now="2018-09-20";
            /*foreach($this->super_model->custom_query("SELECT * FROM receive_head WHERE receive_date BETWEEN '$startdate' AND '$now'") as $head){*/
            foreach($this->super_model->custom_query("SELECT * FROM receive_head WHERE receive_date  BETWEEN '$startdate' AND '$now'") as $head){   
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num1, "Date: ".$head->receive_date);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num1, "DR No.: ".$head->dr_no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$num1, "SI No.: ".$head->si_no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num1, "PO No.: ".$head->po_no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$num1, "PCF: ".$head->pcf);
            
            /*foreach($this->super_model->custom_query("SELECT * FROM receive_details WHERE receive_id = '$head->receive_id'") as $det){*/
            foreach($this->super_model->custom_query("SELECT * FROM receive_details WHERE receive_id = '$head->receive_id'") as $det){
            $num1++;
            $purpose = $this->super_model->select_column_where('purpose', 'purpose_desc', 'purpose_id', $det->purpose_id);
            $enduse = $this->super_model->select_column_where('enduse', 'enduse_name', 'enduse_id', $det->enduse_id);     
            $department = $this->super_model->select_column_where('department', 'department_name', 'department_id', $det->department_id);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num1, "PR/JO#: ".$det->pr_no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num1, "Department: ".$department);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$num1, "End-Use: ".$enduse);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num1, "Purpose:".$purpose);

            foreach($this->super_model->custom_query("SELECT * FROM receive_items WHERE rd_id = '$det->rd_id'") AS $q){
            $num1++;
            $inspected_by = $this->super_model->select_column_where("employees", "employee_name", "employee_id", $q->inspected_by);
            $serial = $this->super_model->select_column_where("serial_number", "serial_no", "serial_id", $q->serial_id);
            $supplier = $this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $q->supplier_id);
            $item = $this->super_model->select_column_where('items', 'item_name', 'item_id', $q->item_id);
            $brand = $this->super_model->select_column_where("brand", "brand_name", "brand_id", $q->brand_id);
            $cat_no = $q->catalog_no;
            $cost = $q->item_cost;
            $rec_qty = $q->received_qty;
            $expected_qty = $q->expected_qty;
            $remarks = $q->remarks;
            foreach($this->super_model->select_custom_where("items", "item_id = '$q->item_id'") AS $itema){
                $unit = $this->super_model->select_column_where('uom', 'unit_name', 'unit_id', $itema->unit_id);
            }
            $total = $rec_qty * $cost;
            $part = $this->super_model->select_column_where('items', 'original_pn', 'item_id', $q->item_id);

            if($det->rd_id == $q->rd_id){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$num1, $x);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$num1, $unit);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$num1, $part);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$num1, $item);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$num1, $expected_qty);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$num1, $rec_qty);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$num1, $supplier);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$num1, $cat_no);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I'.$num1, $brand);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J'.$num1, $serial);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K'.$num1, $cost);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$num1, $total);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M'.$num1, $inspected_by);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$num1, $remarks);
            
            $x++;
            /*$objPHPExcel->getActiveSheet()->getStyle('AB'.$num)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

            $objPHPExcel->getActiveSheet()->mergeCells('A'.$num.":E".$num);
            $objPHPExcel->getActiveSheet()->mergeCells('F'.$num.":G".$num);
            $objPHPExcel->getActiveSheet()->mergeCells('H'.$num.":K".$num);
            $objPHPExcel->getActiveSheet()->mergeCells('L'.$num.":M".$num);
            $objPHPExcel->getActiveSheet()->mergeCells('N'.$num.":O".$num);
            $objPHPExcel->getActiveSheet()->mergeCells('P'.$num.":Q".$num);
            $objPHPExcel->getActiveSheet()->mergeCells('R'.$num.":S".$num);*/
            /*$objPHPExcel->getActiveSheet()->getStyle('N'.$num.":S".$num)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);*/
            $objPHPExcel->getActiveSheet()->getProtection()->setSheet(true);
            $objPHPExcel->getActiveSheet()->protectCells('A'.$num1.":S".$num1,'admin');
            $num++;       
            $num4++;       
            $num5++; 
            $num1++;             
             
            }   
            }
            $num6++;       
            $num7++;       
            $num8++;       
            $num9++;
        }
        $num1++;    
        $num2++;    
        $num3++;
        $num4++;
        }
        /*$objPHPExcel->getActiveSheet()->mergeCells('A1:E1');
        $objPHPExcel->getActiveSheet()->mergeCells('F1:G1');
        $objPHPExcel->getActiveSheet()->mergeCells('H1:K1');
        $objPHPExcel->getActiveSheet()->mergeCells('L1:M1');
        $objPHPExcel->getActiveSheet()->mergeCells('N1:O1');
        $objPHPExcel->getActiveSheet()->mergeCells('P1:Q1');
        $objPHPExcel->getActiveSheet()->mergeCells('R1:S1');
        $objPHPExcel->getActiveSheet()->getStyle('A1:S1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A1:S1')->getFont()->setBold(true);*/
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        if (file_exists($exportfilename))
        unlink($exportfilename);
        $objWriter->save($exportfilename);
        unset($objPHPExcel);
        unset($objWriter);   
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="All Receive.xlsx"');
        readfile($exportfilename);
    }
}
?>
