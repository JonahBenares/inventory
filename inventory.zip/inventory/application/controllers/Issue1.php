<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Issue extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');

        date_default_timezone_set("Asia/Manila");
        $this->load->model('super_model');
        $this->dropdown['department'] = $this->super_model->select_all_order_by('department', 'department_name', 'ASC');
        $this->dropdown['purpose'] = $this->super_model->select_all_order_by('purpose', 'purpose_desc', 'ASC');
        $this->dropdown['enduse'] = $this->super_model->select_all_order_by('enduse', 'enduse_name', 'ASC');
         $this->dropdown['prno'] = $this->super_model->select_join_where("receive_details","receive_head", "saved='1' AND create_date BETWEEN CURDATE() - INTERVAL 60 DAY AND CURDATE()","receive_id");
        function arrayToObject($array){
            if(!is_array($array)) { return $array; }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) { $object->$name = arrayToObject($value); }
                }
                return $object;
            } else {
                return false;
            }
        }
    }

   
    public function load_issue(){
        $id=$this->uri->segment(3);
        $data['id']=$id;

        foreach($this->super_model->select_row_where("request_head", "request_id", $id) AS $hd){
            $data['head'][] = array(
                "mreqf_no"=>$hd->mreqf_no,
                "request_date"=>$hd->request_date,
                "request_time"=>$hd->request_time,
                "department"=>$this->super_model->select_column_where("department", "department_name", "department_id", $hd->department_id),
                "purpose"=>$this->super_model->select_column_where("purpose", "purpose_desc", "purpose_id", $hd->purpose_id),
                "enduse"=>$this->super_model->select_column_where("enduse", "enduse_name", "enduse_id", $hd->enduse_id),
                "prno"=>$hd->pr_no,
                "borrowfrom"=>$hd->borrowfrom_pr,
                "remarks"=>$hd->remarks,

            );
        }

        foreach($this->super_model->select_row_where("request_items", "request_id", $id) AS $it){
            $data['items'][] = array(
                "catalog_no"=>$it->catalog_no,
                "siid"=>$it->si_id,
                "uom"=>$it->uom,
                "quantity"=>$it->quantity,
                "pn_no"=>$it->pn_no,
                "item"=>$this->super_model->select_column_where("items", "item_name", "item_id", $it->item_id),
                "supplier"=>$this->super_model->select_column_where("supplier", "supplier_name", "supplier_id", $it->supplier_id),
                "brand"=>$this->super_model->select_column_where("brand", "brand_name", "brand_id", $it->brand_id)

            );
        }
        $this->load->view('template/header');
        $this->load->view('template/sidebar',$this->dropdown);
        $this->load->view('issue/load_issue',$data);
        $this->load->view('template/footer');
    }

    public function mreqflist(){
        $mreqf=$this->input->post('mreqf');

        $rows=$this->super_model->count_custom_where("request_head","mreqf_no LIKE '%$mreqf%' AND saved = '1'");
        if($rows!=0){
             echo "<ul id='name-item'>";
            foreach($this->super_model->select_custom_where("request_head","mreqf_no LIKE '%$mreqf%' AND saved = '1'") AS $mr){ 
                    ?>
                   <li onClick="selectMreqF('<?php echo $mr->mreqf_no; ?>','<?php echo $mr->request_id; ?>')"><strong><?php echo $mr->mreqf_no;?> </strong></li>
                <?php 
            }
             echo "<ul>";
        }
    }

   
}
?>
