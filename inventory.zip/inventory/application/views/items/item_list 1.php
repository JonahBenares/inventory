<script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/js/item.js"></script>
<script src="<?php echo base_url(); ?>assets/jquery.min.js"></script>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
<div class="row">
	<ol class="breadcrumb">
		<li><a href="#">
			<em class="fa fa-home"></em>
		</a></li>
		<li class="active">Items</li>
	</ol>
</div><!--/.row-->
<div class="row">
	<div class="col-lg-12">
		<br>
	</div>
</div><!--/.row-->

<div id="loader">
  <figure class="one"></figure>
  <figure class="two">loading</figure>
</div>

<div id="itemslist" style="display: none">	

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default shadow">
				<div class="panel-heading">
					ITEM LIST
					<div class="pull-right">
						<a class=" clickable panel-toggle panel-button-tab-right shadow"  data-toggle="modal" data-target="#modal_addnew">
							<span class="fa fa-search"></span>
						</a>
						<a class="clickable panel-toggle panel-button-tab-right shadow"  href="<?php echo base_url(); ?>index.php/items/add_item_first">
							<span class="fa fa-plus"></span></span>
						</a>
					</div>
				</div>
				<div class="panel-body">
					<div class="canvas-wrapper">
						<div class="row" style="padding:0px 10px 0px 10px">
							<?php 
						
							if(!empty($_POST)){
								
								if($count_query==0){
									?>
									<div class='alert alert-warning alert-shake'>
										<center>
											<strong>Oops!</strong> Your search query returns empty.
											<a href='<?php echo base_url(); ?>index.php/items/item_list' class='remove_filter alert-link'>Remove Filters</a>. 
										</center>
									</div>
									<?php
								} else {
									?>								
									<div class='alert alert-warning alert-shake'>
										<center>
											<strong>Filters applied:</strong> <?php echo  $filter; ?>.
											<a href='<?php echo base_url(); ?>index.php/items/item_list' class='remove_filter alert-link'>Remove Filters</a>. 
										</center>
									</div>
							<?php  }	}?>
						</div>
						<table class="table table-bordered table-hover" id="item_table">
							<thead>
								<tr>
									<th width="8%">Original PN</th>
									<th width="50%">Item Description</th>
									<th width="10%">Warehouse Location</th>
									<th width="10%">Bin</th>
									<th width="5%">Qty</th>
									<th width="5%">Minimum Order Qty</th>
									<th width="12%">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								
								foreach($items AS $itm) { ?>
								<tr>
									<td><?php echo $itm['original_pn']; ?></td>
									<td><?php echo $itm['item_name']?></td>
									<td><?php echo $itm['warehouse'];?></td>
									<td><?php echo $itm['bin'];?></td>
									<td align="center"><?php echo $itm['quantity']?></td>
									<td align="center"><?php echo $itm['minimum'];?></td>
									<td>
										<?php ?>
										<a href="<?php echo base_url(); ?>index.php/items/view_item_detail/<?php echo $itm['item_id'];?>" class="btn btn-warning btn-xs" target='_blank' title="VIEW"><span class="fa fa-eye"></span></a>
										<a href="<?php echo base_url(); ?>index.php/items/update_item/<?php echo $itm['item_id'];?>" class="btn btn-primary btn-xs" title="UPDATE"><span class="fa fa-pencil-square-o"></span></a>
										<a  href="<?php echo base_url(); ?>index.php/items/delete_item/<?php echo $itm['item_id'];?>" onclick="confirmationDelete(this);return false;" class="btn btn-danger btn-xs" title="DELETE" alt='DELETE'><span class="fa fa-trash-o"></span></a>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!---MO-D-A-L-->
	<div class="modal fade" id="modal_addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
		<div class="modal-dialog" role="document">
			<div class="modal-content modbod">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Search</h4>
				</div>
				<form method="POST" action = "<?php echo base_url(); ?>index.php/items/search_item" role="search">
					<div class="modal-body">

						<table style="width:100%">
							<tr>
								<td class="td-sclass"><label for="category">Category:</label></td>
								<td class="td-sclass">
									<select class="form-control" name="category" id='category'>
										<option value='' selected>-Choose Category-</option>
										<?php foreach($category as $cat) { ?>
										<option value='<?php echo $cat->cat_id; ?>'><?php echo $cat->cat_name; ?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td width="25%" class="td-sclass"><label for="sub">Sub Category:</label></td>
								<td width="75%" class="td-sclass">
									<select class="form-control" name="subcat" id = "subcat">
										<option value='' selected>-Choose Sub Category-</option>
									</select>
								</td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="desc">Item Description:</label></td>
								<td class="td-sclass"><input class="form-control" name="item_desc"></td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="pn">PN/Catalog No.:</label></td>
								<td class="td-sclass"><input class="form-control" name="pn"></td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="sub">Group:</label></td>
								<td class="td-sclass">
									<select class="form-control" name="group">
										<option value='' selected>-Choose Group-</option>
										<?php foreach($group as $gro) { ?>
										<option value='<?php echo $gro->group_id; ?>'><?php echo $gro->group_name; ?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="sub">Section:</label></td>
								<td class="td-sclass">
									<select class="form-control" name="section">
										<option value='' selected>-Choose Section-</option>
										<?php foreach($location as $loc) { ?>
										<option value='<?php echo $loc->location_id; ?>'><?php echo $loc->location_name; ?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="sub">Bin:</label></td>
								<td class="td-sclass">
									<select class="form-control" name="bin">
										<option value='' selected>-Choose Bin-</option>
										<?php foreach($bin as $bin) { ?>
										<option value='<?php echo $bin->bin_id; ?>'><?php echo $bin->bin_name; ?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="sub">Warehouse:</label></td>
								<td class="td-sclass">
									<select class="form-control" name="warehouse">
										<option value='' selected>-Choose Warehouse-</option>
										<?php foreach($warehouse as $wh) { ?>
										<option value='<?php echo $wh->warehouse_id; ?>'><?php echo $wh->warehouse_name; ?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="sub">Rack:</label></td>
								<td class="td-sclass">
									<input class="form-control" name="rack">
								</td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="sub">Barcode:</label></td>
								<td class="td-sclass">
									<input type="text" class="form-control" name="barcode">
								</td>
							</tr>
							<tr>
								<td class="td-sclass"><label for="sub">Expiration:</label></td>
								<td class="td-sclass">
									<input type="text" class="form-control" name="expiration">
								</td>
							</tr>
						</table>					
					</div>
					<div class="modal-footer">
						<input type="submit" name="searchbtn" class="search-btn btn btn-default shadow" value="Search">
					</div>
					<input type="hidden" name="baseurl" id="baseurl" value="<?php echo base_url(); ?>">
				</form>
			</div>
		</div>
	</div>
	<div class="modal fade" id="modal_delete_item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="alert alert-danger">
				<center>
				  	<h2 class="alert-link"><strong><span class="fa fa-exclamation-triangle" aria-hidden="true"></span> DANGER!</strong></h2>
				  	<hr>
				  	Are you sure you want to delete this?
				  	<br>
				  	<br>					  	
				  	<a href="#" class="btn btn-default " data-dismiss="modal">NO</a>&nbsp<a href="#" class="btn btn-danger">YES</a>.
			  	</center>
			</div>
		</div>
	</div>
