<script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/js/reports.js"></script>
<style type="text/css">
	#name-item{
		width: 47%!important;
	}
	.arrow-top{
	    content: "";
	    position: absolute;
	    top: -6%;
	    left: 93%;
	    transform: rotate(180deg);
	    margin-left: -5px;
	    border-width: 5px;
	    border-style: solid;
	    border-color: #e66513 transparent transparent transparent;
	}
	.arrow-top2{
	    content: "";
	    position: absolute;
	    top: -4%;
	    left: 93%;
	    transform: rotate(180deg);
	    margin-left: -5px;
	    border-width: 5px;
	    border-style: solid;
	    border-color: #e66513 transparent transparent transparent;
	}
</style>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<ol class="breadcrumb">
			<li><a href="#">
				<em class="fa fa-home"></em>
			</a></li>
			<li class=""><a href="<?php echo base_url(); ?>index.php/items/item_list">Items </a></li>
			<li class="active"> Add New</li>
		</ol>
	</div><!--/.row-->
	
	<div class="row">
		<div class="col-lg-12">
			<br>
		</div>
	</div><!--/.row-->

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default shadow">
				<div class="panel-heading" style="height:20px">
				</div>
				<div class="panel-body">
					<div class="canvas-wrapper">
						<div class="col-lg-12">
							<form method="POST" action="<?php echo base_url(); ?>index.php/reports/generateReport">
								<table width="100%">
									<tr>
										<td width="15%">Search Item:</td>
										<td>
											<input type="text" name="item" id="item" class="form-control" autocomplete='off'>
											<span id="suggestion-item"></span>
										</td>
										<td>
											<input type="submit" name="search_inventory" value='Generate Report' class="btn btn-warning" >
										</td>
									</tr>
								</table>
								<input type="hidden" name="baseurl" id="baseurl" value="<?php echo base_url(); ?>">
								<input type="hidden" name="item_id" id="item_id">
								<input type="hidden" name="original_pn" id="original_pn">
							</form>
							<br>
							<p class="pname"><?php echo $itemdesc;

							if(!empty($items)){ ?>
								
									<a href="" class="btn btn-info pull-right">Overall Quantity: <span style="font-size: 25px" class="badge animated rubberBand "><?php echo $totalbal; ?></span></a>
								<?php } ?>
								
							</p>
							<table class="table table-hover table-bordered">
								<thead>
									<tr>
										<td align="center"><strong>PR#</strong></td>
										<td align="center"><strong>Brand</strong></td>
										<td align="center"><strong>Cat No.</strong></td>
										<td align="center"><strong>Expected Qty</strong></td>
										<td align="center"><strong>Min Order Qty</strong></td>
										<td align="center"><strong>Qty Received</strong></td>
										<td align="center"><strong>Qty Issued</strong></td>
										<td align="center"><strong>Balance</strong></td>
									</tr>
								</thead>
								<tbody>
									<?php 
									if(!empty($items)){
									foreach($items AS $it) { 
										foreach($details AS $det){
											if($it['rdid'] == $det['rdid']){
									?>

									<tr>
										<td align="center"><?php echo $det['prno'];?></td>
										<td align="center"><?php echo $it['brand']; ?></td>
										<td align="center"><?php echo $it['catalog_no']; ?></td>
										<td align="center"><?php echo $it['exqty'];?></td>
										<td align="center"><?php echo $it['moq'];?></td>
										<td align="center">
											<li class="dropdown" style="list-style:none;margin:0px;height:10px">
												<a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
													<h4 style="margin:0px">
														<span class="label label-warning"><?php echo $it['quantity']; ?></span>
													</h4>
												</a>
												<ul class="dropdown-menu dropdown-alerts animated fadeInDown" style="top:20px;border:1px solid #e66614;left: -190px;">
													<span class="arrow-top2"></span>
													<li style="padding:10px">
														<table class="table table-hover" style="margin:0px">
															<tr>
																<td class="pad-t-4" width="5%"><strong>Supplier:</strong></td>
																<td class="pad-t-4" width="95%"><label style="color:#555;font-weight: 600"><?php echo $it['supplier']; ?></label ></td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>MRF No:</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['mrfno']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>DR No:</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['drno']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>PO No:</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['pono']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>JO No:</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['jono']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>SI NO:</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['sino']; ?></label >
																</td>
															</tr>

															<tr>
																<td class="pad-t-4"><strong>Enduse:</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['enduse']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>Purpose:</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $det['purpose'];?></label >
																</td>
															</tr>
														</table>
													</li>
												</ul>
											</li>
										</td>
										<td align="center">
											<li class="dropdown" style="list-style:none;margin:0px;height:10px">
												<a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
													<h4 style="margin:0px">
														<span class="label label-warning"><?php echo $it['issueqty']; ?></span>
													</h4>
												</a>
												<ul class="dropdown-menu dropdown-alerts animated fadeInUp" style="top:20px;border:1px solid #e66614;left: -410px;width:500px">
													<span class="arrow-top"></span>
													<li style="padding:10px">
														<table class="table table-hover" style="margin:0px">
															<tr>
																<td class="pad-t-4" width="20%"><strong>MIF No.</strong></td>
																<td class="pad-t-4" width="80%"><label style="color:#555;font-weight: 600"><?php echo $it['mifno']; ?></label></td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>MReqF No.</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['mreqfno']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>Department</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['dept']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>End Use</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['enduse']; ?></label >
																</td>
															</tr>
															<tr>
																<td class="pad-t-4"><strong>Purpose</strong></td>
																<td class="pad-t-4">
																	<label style="color:#555;font-weight: 600"><?php echo $it['purpose']; ?></label >
																</td>
															</tr>
														</table>
													</li>
												</ul>
											</li>
										</td>								
										<td align="center" style="background-color: #ffdea1; font-weight: bold"><?php echo $it['balance']; ?></td>	
									</tr>
									<?php } }
									} } else { ?>
										<tr>
											<td align="center" colspan='9'><center>No Data Available.</center></td>									
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript"></script>