<script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/js/receive.js"></script>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<ol class="breadcrumb">
			<li><a href="#">
				<em class="fa fa-home"></em>
			</a></li>
			<li class=""><a href="<?php echo base_url(); ?>index.php/receive/receive_list">Receive </a></li>
			<li class="active"> Delivery Receipt</li>
		</ol>
	</div><!--/.row-->
	
	<div class="row">
		<div class="col-lg-12">
			<br>
		</div>
	</div><!--/.row-->

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default shadow">
				<div class="panel-heading" style="height:20px">
				</div>
				<div class="panel-body">
					<div class="canvas-wrapper">
						<table width="100%">
							<?php foreach($head as $h){ ?>
							<tr>
								<td width="5%"></td>
								<td width="5%"><p class="nomarg">Date:</p></td>
								<td width="20%"><label class="labelStyle"><?php echo date('F j, Y',strtotime($h->receive_date)); ?></label></td>
								<td width="5%"></td>
								<td>
									<div class="pull-right">
										<!-- <?php if($r->saved==0){ ?> -->
										<a href="<?php echo base_url(); ?>index.php/receive/add_receive_first/<?php echo $h->receive_id;?>" class="btn btn-info btn-sm"><span class="fa fa-pencil"></span> Update</a>
										<!-- <?php } ?> -->
										<a href="<?php echo base_url(); ?>index.php/receive/mrf/<?php echo $h->receive_id;?>" class="btn btn-warning btn-sm" target = "_blank"><span class="fa fa-print"></span> Print</a>
									</div>									
								</td>
							</tr>
							<tr>
								<td></td>
								<td><p class="nomarg">DR #:</p></td>
								<td> <h5 class="nomarg"><?php echo $h->dr_no; ?></h5></td>
								<td><p class="nomarg">PO #:</p></td>
								<td> <h5 class="nomarg"><?php echo $h->po_no; ?></h5></td>
							</tr>
							<tr>
								<td></td>
								<td><p class="nomarg">JO #:</p></td>
								<td> <h5 class="nomarg"><?php echo $h->jo_no; ?></h5></td>
								<td><p class="nomarg">SI #:</p></td>
								<td> <h5 class="nomarg"><?php echo $h->si_no; ?></h5></td>
							</tr>
							<?php } ?>
						</table>
						<div class="col-lg-12">
							<?php
							 if(!empty($details)){
							 foreach($details AS $d){ ?>
							<div class="row border-class shadow">
								<div style="padding:0px 15px">
									<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10"  >
										<h3 class="nomarg">PR #: <?php echo $d['prno']; ?></h3>
									<p class="nomarg"><strong>End-Use: <?php echo $d['enduse']; ?></strong></p>
									<p ><strong>Purpose: <?php echo $d['purpose']; ?></strong> </p>
									</div>									
									<table width="100%" class="table table-bordered " >
										<tr >
											<th class="tr-bottom" width="5%"><center>Item No.</center></th>
											<th class="tr-bottom" width="15%"><center>Supplier</center></th>
											<th class="tr-bottom" width="15%"><center>Description</center></th>

											<th class="tr-bottom" width="10%"><center>Brand</center></th>
											<th class="tr-bottom" width="5%"><center>Cat. No.</center></th>
											<th class="tr-bottom" width="5%"><center>Unit Cost</center></th>

											<th class="tr-bottom" width="10%"><center>Expected Qty</center></th>
											<th class="tr-bottom" width="10%"><center>Delivered / Received</center></th>
											<th class="tr-bottom" width="10%"><center>Inspected By</center></th>
											<th class="tr-bottom" width="5%"><center>UOM</center></th>
											<th class="tr-bottom" width="20%"><center>Remarks</center></th>
											<th><a class="btn btn-default" ><span class="fa fa-pencil"></span></a></th>
										</tr>
										<?php 
											$itemno=1;
											foreach($items AS $it){ 
												if($it['rdid'] == $d['rdid']) { 
										?>
											<tr>
												<td><center><?php echo $itemno; ?></center></td>
												<td><?php echo $it['supplier']; ?></td>
												<td><?php echo $it['item']; ?></td>
												<td><?php echo $it['brand']; ?></td>
												<td><?php echo $it['catalog_no']; ?></td>
												<td><?php echo $it['unit_cost']; ?></td>
												<td><center><?php echo $it['expqty']; ?></center></td>
												<td><center><?php echo $it['recqty']; ?></center></td>
												<td><center><?php echo $it['inspected']; ?></center></td>
												<td><center><?php echo $it['unit']; ?></center></td>
												<td><?php echo $it['remarks']; ?></td>
												<td><a onclick="update_prcmrk()" title="Update Price & Remarks" class="btn btn-info"><span class="fa fa-pencil"></span></a></td>
											</tr>
										<?php
											$itemno++;
												}
									 		} 
									 	?>
									</table>
								</div>
							</div>
							<?php }
							} ?>
							<hr>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<script>
function update_prcmrk() {
    var myWindow = window.open("<?php echo base_url(); ?>index.php/receive/update_prc_mrk", "", "top=100,left=450,width=500,height=350");
}
</script>