<body style="padding:0px 10px">
<div class="border-class shadow" style="background-color: #fff">
	<div class="container">
		<div class="row">
			<center><h4 class="pname">Update Price & Remarks</h4></center>
			<div class="col-lg-12">
				<p>Price:
					<input type="text" class="form-control" name="">
				</p>
				<p>Remarks:
					<textarea rows="3" class="form-control"></textarea>
				</p>
			</div>
		</div>
	</div>
</div>
</body>