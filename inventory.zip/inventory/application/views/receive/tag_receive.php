<div class="container-fluid" > 
	<div class="row" style="margin-top:-50px">
		<div class="col-md-12">
			<div class="panel panel-default shadow">
				<div class="panel-heading" style="height:20px">
				</div>
				<div class="panel-body">
					<div class="canvas-wrapper">
						<div>
							<div class="col-lg-12">
								<form>
									<table width="100%">
										<tr>
											<td></td>																						
											<td><p class="pull-right">Item Name: &nbsp</p></td>
											<td colspan="2" style="padding-bottom:10px">
												<select class="form-control" type="text" name="item">
													<option>sad</option>
													<option>very sad</option>
													<option>very very sad</option>
													<option>very very very sad</option>
													<option>very very very very sad</option>
													<option>very very very very very sad</option>
												</select>
											</td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td></td>
											<td>Supplier:</td>
											<td>Category:</td>
											<td>Brand:</td>
											<td>Qty:</td>
											<td>Unit Cost:</td>
										</tr>
										<tr>
											<td width="7%">New Item:</td>
											<td width="25%">
												<select class="form-control" type="text" name="supplier">
													<option>sad</option>
													<option>very sad</option>
													<option>very very sad</option>
													<option>very very very sad</option>
													<option>very very very very sad</option>
													<option>very very very very very sad</option>
												</select>
											</td>
											<td width="22%"><input class="form-control" type="text" name="Category"></td>
											<td width="21%"><input class="form-control" type="text" name="Brand"></td>
											<td width="11%"><input class="form-control" type="text" name="Qty"></td>
											<td width="14%"><input class="form-control" type="text" name="Unit"></td>
										</tr>
									</table>								
									<hr>
									<table class="table table-hover table-bordered" >
										<thead>
											<tr>
												<th width="5%"><span><input class="form-control" type="checkbox" name="chek"></span></th>
												<th width="30%">Supplier</th>
												<th width="20%">Category</th>
												<th width="20%">Brand</th>
												<th width="10%">Qty</th>
												<th width="15%">Unit Cost</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td><input class="form-control" type="checkbox" name="chek"></td>
												<td><p>Supplier</p></td>
												<td><p>Category</p></td>
												<td><p>Brand</p></td>
												<td><input class="form-control" type="text" name="Category" value="3246734"></td>
												<td><input class="form-control" type="text" name="Category" value="3246734"></td>
											</tr>
										</tbody>
									</table>
									<center>
										<button class="btn btn-warning " style="width: 50%">SAVE</button>
									</center>									
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
