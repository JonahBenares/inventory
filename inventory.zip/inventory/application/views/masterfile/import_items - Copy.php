<script src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<ol class="breadcrumb">
			<li><a href="#">
				<em class="fa fa-home"></em>
			</a></li>
			<li class=""><a href="<?php echo base_url(); ?>index.php/masterfile/import_items">Import Items </a></li>
		</ol>
	</div><!--/.row-->
	<div class="row">
		<div class="col-md-12">
			<br>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default shadow">
				<div class="panel-heading" style="height:20px">
				</div>
				<div class="panel-body">
					<div class="canvas-wrapper">
						<div style="padding: 20px 50px 20px 50px">
							<div class="col-lg-12">
								
									<div class="row" style="padding: 0px 0px 10px 0px">
										<div class="col-lg-12">
											<label>Upload Excel Files:</label>
										</div>
										
									</div>
									<div class="row" style="padding: 0px 0px 10px 0px">
										<div class="col-lg-3">
											<strong>File to Upload</strong>
										</div>
										<div class="col-lg-3">
											<strong>Format</strong>
										</div>
										<div class="col-lg-4">
											<strong>Upload Files</strong>
										</div>
										<div class="col-lg-2">
											
										</div>
									
									</div>
								<form method='POST' action='upload_excel' enctype="multipart/form-data">
									<div class="row" style="padding: 0px 0px 10px 0px">
										<div class="col-lg-3">
											Item Inventory
										</div>
										<div class="col-lg-3">
											<a href='<?php echo base_url(); ?>uploads/excel/inventory_format.xlsx'>Download Inventory Format</a>
										</div>
										<div class="col-lg-4">
											<input type='file' name='excelfile' required>
										</div>
										<div class="col-lg-2">
											<input type='submit' class="btn btn-warning form-control" style="background: #ff5d00" value='Upload' name='uploadexcel'>
										</div>
									
									</div>
								</form>
								<form method='POST' action='upload_excel_begbal' enctype="multipart/form-data">
									<div class="row" style="padding: 0px 0px 10px 0px">
										<div class="col-lg-3">
											Beginning Balance
										</div>
										<div class="col-lg-3">
											<a href='<?php echo base_url(); ?>index.php/masterfile/export_begbal'>Download Beg. Bal. Format</a>
										</div>
										<div class="col-lg-4">
											<input type='file' name='excelfile_begbal' required>
										</div>
										<div class="col-lg-2">
											<input type='submit' class="btn btn-warning form-control" style="background: #ff5d00" value='Upload' name='uploadexcel'>
										</div>
									
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
