<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Signatory</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<br>
			</div>
		</div><!--/.row-->		
		
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default shadow">
					<div class="panel-heading">
						Signatories
						<div class="pull-right">
							<a class=" clickable panel-toggle panel-button-tab-right shadow"  href="<?php echo base_url(); ?>index.php/masterfile/add_signatory">
								<span class="fa fa-plus"></span>
							</a>
						</div>	
					</div>
					<div class="panel-body">
						<div class="canvas-wrapper">
							<table class="table table-bordered table-hover" id="item_table">
								<thead>
									<tr style="font-size: 13px">
										<th style="padding:10px;" width="30%">Employee Name</th>
										<th style="padding:10px;text-align: center">Noted By</th>
										<th style="padding:10px;text-align: center">Inspected By</th>
										<th style="padding:10px;text-align: center">Delivered By</th>
										<th style="padding:10px;text-align: center">Reviewed By</th>
										<th style="padding:10px;text-align: center">Received By</th>
										<th style="padding:10px;text-align: center">Released By</th>
										<th style="padding:10px;text-align: center">Requested By</th>
										<th style="padding:10px;text-align: center">Approved By</th>										
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>Jonah Faye Narazo Benares</td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
									</tr>
									<tr>
										<td >John Lloyd Jamero</td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
									</tr>
									<tr>
										<td>Stephine David Alvero Severino</td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:red;"><span class="fa fa-times"></span></p></td>
										<td align="center"><p style="font-size: 19px;color:green;"><span class="fa fa-check"></span></p></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>