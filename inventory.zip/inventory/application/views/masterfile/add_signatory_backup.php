<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<ol class="breadcrumb">
			<li><a href="#">
				<em class="fa fa-home"></em>
			</a></li>
			<li><a href="<?php echo base_url(); ?>index.php/masterfile/signatory">Signatory</a></li>
			<li class="active">Update Signatory</li>
		</ol>
	</div><!--/.row-->
	
	<div class="row">
		<div class="col-lg-12">
			<br>
		</div>
	</div><!--/.row-->		
	
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default shadow">
				<div class="panel-heading">
					Update Signatories
				</div>
				<div class="panel-body">
					<div class="canvas-wrapper">
						<form method = "POST" action = "<?php echo base_url(); ?>index.php/masterfile/insert_signatory">
							<table class="table table-bordered table-hover">
								<thead>
									<tr style="font-size: 13px" >
										<th style="text-align: center;" width="30%">Employee Name</th>
										<th style="text-align: center;">Noted By</th>
										<th style="text-align: center;">Inspected By</th>
										<th style="text-align: center;">Delivered By</th>
										<th style="text-align: center;">Reviewed By</th>
										<th style="text-align: center;">Received By</th>
										<th style="text-align: center;">Released By</th>
										<th style="text-align: center;">Requested By</th>
										<th style="text-align: center;">Approved By</th>
										<th width="5%"></th>


									</tr>
								</thead>
								<tbody>
									<tr style="background-color: #ffe08e4a">
										<td align="right"></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td align="center"><input style="height: 20px" type="checkbox" name="halo" class="form-control" ><span class="fa fa-caret-down"></span></td>
										<td style="background-color: #ffe08e7a"></td>
									</tr>
									<?php foreach($employee as $emp){ ?>
									<tr>
										<td><input type = "hidden" name = "employee_id[]" value = "<?php echo $emp['employeeid'];?>"><?php echo $emp['employee'];?></td>
										<td><input style="height: 20px" type="checkbox" name="noted[]" value = "1" class="form-control" ></td>
										<td><input style="height: 20px" type="checkbox" name="inspected[]" value = "1" class="form-control" ></td>
										<td><input style="height: 20px" type="checkbox" name="delivered[]" value = "1" class="form-control" ></td>
										<td><input style="height: 20px" type="checkbox" name="reviewed[]" value = "1" class="form-control" ></td>
										<td><input style="height: 20px" type="checkbox" name="received[]" value = "1" class="form-control" ></td>
										<td><input style="height: 20px" type="checkbox" name="released[]" value = "1" class="form-control" ></td>
										<td><input style="height: 20px" type="checkbox" name="requested[]" value = "1" class="form-control" ></td>
										<td><input style="height: 20px" type="checkbox" name="approved[]" value = "1" class="form-control" ></td>
										<td style="background-color: #ffe08e7a">
											<div class="col-md-1" style="padding:0px">											
												<span class="fa fa-caret-left"></span>
											</div>
											<div class="col-md-11" style="padding:0px">
												<input style="height: 20px" type="checkbox" name="halo" class="form-control" >
											</div>
										</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
							<input type='hidden' name='counter' id='counter'>
							<button type="submit" class="btn btn-warning btn-md" style="width:100%">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>